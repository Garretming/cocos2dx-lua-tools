
--------------------------------
-- @module WindowSystem
-- @parent_module ccx

--------------------------------
-- 
-- @function [parent=#WindowSystem] restart 
-- @param self
-- @return WindowSystem#WindowSystem self (return value: ccx.WindowSystem)
        
return nil
