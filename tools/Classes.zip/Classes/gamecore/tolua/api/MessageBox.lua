
--------------------------------
-- @module MessageBox
-- @extend Ref
-- @parent_module ccx

--------------------------------
-- 
-- @function [parent=#MessageBox] create 
-- @param self
-- @param #char msg
-- @param #char title
-- @return MessageBox#MessageBox ret (return value: ccx.MessageBox)
        
--------------------------------
-- 
-- @function [parent=#MessageBox] MessageBox 
-- @param self
-- @param #char msg
-- @param #char title
-- @return MessageBox#MessageBox self (return value: ccx.MessageBox)
        
return nil
