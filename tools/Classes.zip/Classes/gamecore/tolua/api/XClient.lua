
--------------------------------
-- @module XClient
-- @extend Ref
-- @parent_module ccx

--------------------------------
-- 
-- @function [parent=#XClient] isInternetConnectionAvailable 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#XClient] http_send 
-- @param self
-- @param #unsigned int nHandler
-- @param #char url
-- @param #string postData
-- @param #char remark
-- @return XClient#XClient self (return value: ccx.XClient)
        
--------------------------------
-- 
-- @function [parent=#XClient] stopMonitorNetwork 
-- @param self
-- @return XClient#XClient self (return value: ccx.XClient)
        
--------------------------------
-- 
-- @function [parent=#XClient] registerResponseHandler 
-- @param self
-- @param #int nHandler
-- @return XClient#XClient self (return value: ccx.XClient)
        
--------------------------------
-- 
-- @function [parent=#XClient] isInternetConnectionWIFI 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#XClient] send 
-- @param self
-- @param #unsigned int opcode
-- @param #char msg
-- @param #unsigned int len
-- @param #int index
-- @return unsigned int#unsigned int ret (return value: unsigned int)
        
--------------------------------
-- 
-- @function [parent=#XClient] setAutoReconnect 
-- @param self
-- @param #bool bValue
-- @return XClient#XClient self (return value: ccx.XClient)
        
--------------------------------
-- 
-- @function [parent=#XClient] isConnected 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#XClient] startMonitorNetwork 
-- @param self
-- @return XClient#XClient self (return value: ccx.XClient)
        
--------------------------------
-- 
-- @function [parent=#XClient] connect 
-- @param self
-- @param #char ip
-- @param #unsigned short port
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#XClient] disconnect 
-- @param self
-- @return XClient#XClient self (return value: ccx.XClient)
        
--------------------------------
-- 
-- @function [parent=#XClient] heartBeatDetection 
-- @param self
-- @return XClient#XClient self (return value: ccx.XClient)
        
--------------------------------
-- 
-- @function [parent=#XClient] destroyInstance 
-- @param self
-- @return XClient#XClient self (return value: ccx.XClient)
        
--------------------------------
-- 
-- @function [parent=#XClient] sleep 
-- @param self
-- @param #unsigned int ms
-- @return XClient#XClient self (return value: ccx.XClient)
        
--------------------------------
-- 
-- @function [parent=#XClient] getInstance 
-- @param self
-- @return XClient#XClient ret (return value: ccx.XClient)
        
return nil
