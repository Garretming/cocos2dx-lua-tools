--------------------------------
-- @module cc

--------------------------------------------------------
-- the cc Configuration
-- @field [parent=#cc] Configuration#Configuration Configuration preloaded module


--------------------------------------------------------
-- the cc Crypto
-- @field [parent=#cc] Crypto#Crypto Crypto preloaded module


--------------------------------------------------------
-- the cc ResourcesMgr
-- @field [parent=#cc] ResourcesMgr#ResourcesMgr ResourcesMgr preloaded module


