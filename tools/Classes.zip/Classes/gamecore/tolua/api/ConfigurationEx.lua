
--------------------------------
-- @module ConfigurationEx
-- @parent_module ccx

--------------------------------
-- 
-- @function [parent=#ConfigurationEx] getBoolValue 
-- @param self
-- @param #string key
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#ConfigurationEx] getIntValue 
-- @param self
-- @param #string key
-- @return int#int ret (return value: int)
        
--------------------------------
-- 
-- @function [parent=#ConfigurationEx] getStringValue 
-- @param self
-- @param #string key
-- @return string#string ret (return value: string)
        
--------------------------------
-- 
-- @function [parent=#ConfigurationEx] setDoubleValue 
-- @param self
-- @param #string key
-- @param #double value
-- @return ConfigurationEx#ConfigurationEx self (return value: ccx.ConfigurationEx)
        
--------------------------------
-- 
-- @function [parent=#ConfigurationEx] setIntValue 
-- @param self
-- @param #string key
-- @param #int value
-- @return ConfigurationEx#ConfigurationEx self (return value: ccx.ConfigurationEx)
        
--------------------------------
-- 
-- @function [parent=#ConfigurationEx] getDoubleValue 
-- @param self
-- @param #string key
-- @return double#double ret (return value: double)
        
--------------------------------
-- 
-- @function [parent=#ConfigurationEx] setBoolValue 
-- @param self
-- @param #string key
-- @param #bool value
-- @return ConfigurationEx#ConfigurationEx self (return value: ccx.ConfigurationEx)
        
--------------------------------
-- 
-- @function [parent=#ConfigurationEx] setStringValue 
-- @param self
-- @param #string key
-- @param #string value
-- @return ConfigurationEx#ConfigurationEx self (return value: ccx.ConfigurationEx)
        
return nil
