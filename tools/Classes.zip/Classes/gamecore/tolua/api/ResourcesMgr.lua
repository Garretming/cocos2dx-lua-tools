
--------------------------------
-- @module ResourcesMgr
-- @extend Ref
-- @parent_module ccx

--------------------------------
-- 
-- @function [parent=#ResourcesMgr] releaseTextrue 
-- @param self
-- @param #string filename
-- @return ResourcesMgr#ResourcesMgr self (return value: ccx.ResourcesMgr)
        
--------------------------------
-- 
-- @function [parent=#ResourcesMgr] removeUnuseResouces 
-- @param self
-- @return ResourcesMgr#ResourcesMgr self (return value: ccx.ResourcesMgr)
        
--------------------------------
-- 
-- @function [parent=#ResourcesMgr] releaseSpriteFramesWithFiles 
-- @param self
-- @param #array_table resources
-- @return ResourcesMgr#ResourcesMgr self (return value: ccx.ResourcesMgr)
        
--------------------------------
-- 
-- @function [parent=#ResourcesMgr] retainTextrue 
-- @param self
-- @param #string filename
-- @return ResourcesMgr#ResourcesMgr self (return value: ccx.ResourcesMgr)
        
--------------------------------
-- 
-- @function [parent=#ResourcesMgr] getTextrue 
-- @param self
-- @param #string filename
-- @return Texture2D#Texture2D ret (return value: cc.Texture2D)
        
--------------------------------
-- 
-- @function [parent=#ResourcesMgr] retainSpriteFramesWithFile 
-- @param self
-- @param #string filename
-- @return ResourcesMgr#ResourcesMgr self (return value: ccx.ResourcesMgr)
        
--------------------------------
-- 
-- @function [parent=#ResourcesMgr] addImageAsyncProgress 
-- @param self
-- @param #unsigned int callback
-- @param #array_table resources
-- @return ResourcesMgr#ResourcesMgr self (return value: ccx.ResourcesMgr)
        
--------------------------------
-- 
-- @function [parent=#ResourcesMgr] addImageAsync 
-- @param self
-- @param #unsigned int callback
-- @param #array_table resources
-- @return ResourcesMgr#ResourcesMgr self (return value: ccx.ResourcesMgr)
        
--------------------------------
-- 
-- @function [parent=#ResourcesMgr] releaseSpriteFramesWithFile 
-- @param self
-- @param #string filename
-- @return ResourcesMgr#ResourcesMgr self (return value: ccx.ResourcesMgr)
        
--------------------------------
-- 
-- @function [parent=#ResourcesMgr] retainSpriteFramesWithFiles 
-- @param self
-- @param #array_table resources
-- @return ResourcesMgr#ResourcesMgr self (return value: ccx.ResourcesMgr)
        
--------------------------------
-- @overload self, unsigned int, array_table         
-- @overload self, string         
-- @function [parent=#ResourcesMgr] addImageSync
-- @param self
-- @param #unsigned int callback
-- @param #array_table resources
-- @return ResourcesMgr#ResourcesMgr self (return value: ccx.ResourcesMgr)

--------------------------------
-- 
-- @function [parent=#ResourcesMgr] isLoadedSpriteFrame 
-- @param self
-- @param #string frameName
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#ResourcesMgr] addSpriteFramesWithFile 
-- @param self
-- @param #string plist
-- @return ResourcesMgr#ResourcesMgr self (return value: ccx.ResourcesMgr)
        
--------------------------------
-- 
-- @function [parent=#ResourcesMgr] getSpineSkeletonData 
-- @param self
-- @param #string filename
-- @return void#void ret (return value: void)
        
--------------------------------
-- 
-- @function [parent=#ResourcesMgr] releaseTextrues 
-- @param self
-- @param #array_table resources
-- @return ResourcesMgr#ResourcesMgr self (return value: ccx.ResourcesMgr)
        
--------------------------------
-- 
-- @function [parent=#ResourcesMgr] retainTextrues 
-- @param self
-- @param #array_table resources
-- @return ResourcesMgr#ResourcesMgr self (return value: ccx.ResourcesMgr)
        
--------------------------------
-- 
-- @function [parent=#ResourcesMgr] addSpineSkeletonDataAsyncProgress 
-- @param self
-- @param #unsigned int handler
-- @param #array_table resources
-- @return ResourcesMgr#ResourcesMgr self (return value: ccx.ResourcesMgr)
        
--------------------------------
-- 
-- @function [parent=#ResourcesMgr] getProtoData 
-- @param self
-- @param #string filename
-- @param #string method
-- @param #int size
-- @return string#string ret (return value: string)
        
--------------------------------
-- 
-- @function [parent=#ResourcesMgr] isSpriteFramesWithFileLoaded 
-- @param self
-- @param #string plist
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#ResourcesMgr] addSpriteFramesWithFiles 
-- @param self
-- @param #array_table plists
-- @return ResourcesMgr#ResourcesMgr self (return value: ccx.ResourcesMgr)
        
--------------------------------
-- 
-- @function [parent=#ResourcesMgr] getFileNameSize 
-- @param self
-- @param #string filename
-- @return size_table#size_table ret (return value: size_table)
        
--------------------------------
-- 
-- @function [parent=#ResourcesMgr] destroyInstance 
-- @param self
-- @return ResourcesMgr#ResourcesMgr self (return value: ccx.ResourcesMgr)
        
--------------------------------
-- 
-- @function [parent=#ResourcesMgr] getInstance 
-- @param self
-- @return ResourcesMgr#ResourcesMgr ret (return value: ccx.ResourcesMgr)
        
return nil
