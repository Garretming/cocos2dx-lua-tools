
--------------------------------
-- @module Configuration
-- @extend Ref
-- @parent_module ccx

--------------------------------
--  Whether or not PVR Texture Compressed is supported.<br>
-- return Is true if supports PVR Texture Compressed.
-- @function [parent=#Configuration] supportsPVRTC 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
--  Whether or not OES_depth24 is supported.<br>
-- return Is true if supports OES_depth24.<br>
-- since v2.0.0
-- @function [parent=#Configuration] supportsOESDepth24 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
--  OpenGL Max Modelview Stack Depth.<br>
-- return The OpenGL Max Modelview Stack Depth.
-- @function [parent=#Configuration] getMaxModelviewStackDepth 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
--  Whether or not shareable VAOs are supported.<br>
-- return Is true if supports shareable VAOs.<br>
-- since v2.0.0
-- @function [parent=#Configuration] supportsShareableVAO 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
--  Whether or not BGRA8888 textures are supported.<br>
-- return Is true if supports BGRA8888 textures.<br>
-- since v0.99.2
-- @function [parent=#Configuration] supportsBGRA8888 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
--  Returns whether or not an OpenGL is supported. <br>
-- param searchName A given search name.<br>
-- return Is true if an OpenGL is supported.
-- @function [parent=#Configuration] checkForGLExtension 
-- @param self
-- @param #string searchName
-- @return bool#bool ret (return value: bool)
        
--------------------------------
--  Whether or not ATITC Texture Compressed is supported.<br>
-- return Is true if supports ATITC Texture Compressed.
-- @function [parent=#Configuration] supportsATITC 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
--  Whether or not the GPU supports NPOT (Non Power Of Two) textures.<br>
-- OpenGL ES 2.0 already supports NPOT (iOS).<br>
-- return Is true if supports NPOT.<br>
-- since v0.99.2
-- @function [parent=#Configuration] supportsNPOT 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
--  Initialize method.<br>
-- return Is true if initialize success.
-- @function [parent=#Configuration] init 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
--  get 3d animate quality
-- @function [parent=#Configuration] getAnimate3DQuality 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
--  Max support point light in shader, for Sprite3D.<br>
-- return Maximum supports point light in shader.<br>
-- since v3.3
-- @function [parent=#Configuration] getMaxSupportPointLightInShader 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
--  OpenGL Max texture size.<br>
-- return The OpenGL Max texture size.
-- @function [parent=#Configuration] getMaxTextureSize 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
--  Sets a new key/value pair  in the configuration dictionary.<br>
-- param key A given key.<br>
-- param value A given value.
-- @function [parent=#Configuration] setValue 
-- @param self
-- @param #string key
-- @param #cc.Value value
-- @return Configuration#Configuration self (return value: cc.Configuration)
        
--------------------------------
--  Max support spot light in shader, for Sprite3D.<br>
-- return Maximum supports spot light in shader.<br>
-- since v3.3
-- @function [parent=#Configuration] getMaxSupportSpotLightInShader 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
--  Whether or not ETC Texture Compressed is supported.<br>
-- return Is true if supports ETC Texture Compressed.
-- @function [parent=#Configuration] supportsETC 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
--  Max support directional light in shader, for Sprite3D.<br>
-- return Maximum supports directional light in shader.<br>
-- since v3.3
-- @function [parent=#Configuration] getMaxSupportDirLightInShader 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
--  Loads a config file. If the keys are already present, then they are going to be replaced. Otherwise the new keys are added.<br>
-- param filename Config file name.
-- @function [parent=#Configuration] loadConfigFile 
-- @param self
-- @param #string filename
-- @return Configuration#Configuration self (return value: cc.Configuration)
        
--------------------------------
--  Whether or not glDiscardFramebufferEXT is supported.<br>
-- return Is true if supports glDiscardFramebufferEXT.<br>
-- since v0.99.2
-- @function [parent=#Configuration] supportsDiscardFramebuffer 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
--  Whether or not OES_Packed_depth_stencil is supported.<br>
-- return Is true if supports OES_Packed_depth_stencil.<br>
-- since v2.0.0
-- @function [parent=#Configuration] supportsOESPackedDepthStencil 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
--  Whether or not S3TC Texture Compressed is supported.<br>
-- return Is true if supports S3TC Texture Compressed.
-- @function [parent=#Configuration] supportsS3TC 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
--  Returns the Configuration info.<br>
-- return The Configuration info.
-- @function [parent=#Configuration] getInfo 
-- @param self
-- @return string#string ret (return value: string)
        
--------------------------------
--  Returns the maximum texture units.<br>
-- return The maximum texture units.<br>
-- since v2.0.0
-- @function [parent=#Configuration] getMaxTextureUnits 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
--  Returns the value of a given key as a double.<br>
-- param key A given key.<br>
-- param defaultValue if not find the value, return the defaultValue.<br>
-- return 
-- @function [parent=#Configuration] getValue 
-- @param self
-- @param #string key
-- @param #cc.Value defaultValue
-- @return Value#Value ret (return value: cc.Value)
        
--------------------------------
--  Gathers OpenGL / GPU information.
-- @function [parent=#Configuration] gatherGPUInfo 
-- @param self
-- @return Configuration#Configuration self (return value: cc.Configuration)
        
--------------------------------
--  Whether or not glMapBuffer() is supported.<br>
-- On Desktop it returns `true`.<br>
-- On Mobile it checks for the extension `GL_OES_mapbuffer`<br>
-- return Whether or not `glMapBuffer()` is supported.<br>
-- since v3.13
-- @function [parent=#Configuration] supportsMapBuffer 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
--  Purge the shared instance of Configuration.
-- @function [parent=#Configuration] destroyInstance 
-- @param self
-- @return Configuration#Configuration self (return value: cc.Configuration)
        
--------------------------------
--  Returns a shared instance of Configuration.<br>
-- return An autoreleased Configuration object.
-- @function [parent=#Configuration] getInstance 
-- @param self
-- @return Configuration#Configuration ret (return value: cc.Configuration)
        
return nil
