
--------------------------------
-- @module Crypto
-- @parent_module ccx

--------------------------------
--  @brief Encrypt data with XXTEA algorithm, return ciphertext, free ciphertext after used 
-- @function [parent=#Crypto] encryptXXTEA 
-- @param self
-- @param #char plaintext
-- @param #int plaintextLength
-- @param #int resultLength
-- @return string#string ret (return value: string)
        
--------------------------------
--  @brief Decrypt data with XXTEA algorithm, return plaintext, free plaintext after used 
-- @function [parent=#Crypto] decryptXXTEA 
-- @param self
-- @param #char ciphertext
-- @param #int ciphertextLength
-- @param #int resultLength
-- @return string#string ret (return value: string)
        
--------------------------------
-- 
-- @function [parent=#Crypto] MD5File 
-- @param self
-- @param #char path
-- @return string#string ret (return value: string)
        
--------------------------------
--  @brief Decoding Base64 string to data, return decoded data length 
-- @function [parent=#Crypto] decodeBase64 
-- @param self
-- @param #char input
-- @param #int inputLength
-- @param #int outputBufferLength
-- @return string#string ret (return value: string)
        
--------------------------------
--  @brief Encoding data with Base64 algorithm, return encoded string length 
-- @function [parent=#Crypto] encodeBase64 
-- @param self
-- @param #char input
-- @param #int inputLength
-- @param #int outputBufferLength
-- @return string#string ret (return value: string)
        
--------------------------------
--  @brief Calculate MD5, get MD5 code 
-- @function [parent=#Crypto] MD5 
-- @param self
-- @param #char input
-- @param #int inputLength
-- @return string#string ret (return value: string)
        
return nil
