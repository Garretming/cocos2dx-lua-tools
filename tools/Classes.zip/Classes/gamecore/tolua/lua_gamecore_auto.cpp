#include "lua_gamecore_auto.hpp"
#include "cocos2d.h"
#include "gamecore/crypto/Crypto.h"
#include "gamecore/ui/ResourcesMgr.h"
#include "gamecore/ui/ConfigurationEx.h"
#include "gamecore/net/XClient.h"
#include "gamecore/ui/MessageBox.h"
#include "gamecore/ui/WindowSystem.h"
#include "scripting/lua-bindings/manual/tolua_fix.h"
#include "scripting/lua-bindings/manual/LuaBasicConversions.h"

int lua_lua_gamecore_Crypto_encryptXXTEA(lua_State* tolua_S)
{
    int argc = 0;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertable(tolua_S,1,"ccx.Crypto",0,&tolua_err)) goto tolua_lerror;
#endif

    argc = lua_gettop(tolua_S) - 1;

    if (argc == 3)
    {
        const char* arg0;
        int arg1;
        int arg2;
        std::string arg0_tmp; ok &= luaval_to_std_string(tolua_S, 2, &arg0_tmp, "ccx.Crypto:encryptXXTEA"); arg0 = arg0_tmp.c_str();
        ok &= luaval_to_int32(tolua_S, 3,(int *)&arg1, "ccx.Crypto:encryptXXTEA");
        ok &= luaval_to_int32(tolua_S, 4,(int *)&arg2, "ccx.Crypto:encryptXXTEA");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_Crypto_encryptXXTEA'", nullptr);
            return 0;
        }
        std::string& ret = gamecore::crypto::Crypto::encryptXXTEA(arg0, arg1, arg2);
        lua_pushlstring(tolua_S,ret.c_str(),ret.length());
        lua_pushinteger(tolua_S, arg2);
        return 2;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "ccx.Crypto:encryptXXTEA",argc, 3);
    return 0;
#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_Crypto_encryptXXTEA'.",&tolua_err);
#endif
    return 0;
}
int lua_lua_gamecore_Crypto_decryptXXTEA(lua_State* tolua_S)
{
    int argc = 0;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertable(tolua_S,1,"ccx.Crypto",0,&tolua_err)) goto tolua_lerror;
#endif

    argc = lua_gettop(tolua_S) - 1;

    if (argc == 3)
    {
        const char* arg0;
        int arg1;
        int arg2;
        std::string arg0_tmp; ok &= luaval_to_std_string(tolua_S, 2, &arg0_tmp, "ccx.Crypto:decryptXXTEA"); arg0 = arg0_tmp.c_str();
        ok &= luaval_to_int32(tolua_S, 3,(int *)&arg1, "ccx.Crypto:decryptXXTEA");
        ok &= luaval_to_int32(tolua_S, 4,(int *)&arg2, "ccx.Crypto:decryptXXTEA");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_Crypto_decryptXXTEA'", nullptr);
            return 0;
        }
        std::string& ret = gamecore::crypto::Crypto::decryptXXTEA(arg0, arg1, arg2);
        lua_pushlstring(tolua_S,ret.c_str(),ret.length());
        lua_pushinteger(tolua_S, arg2);
        return 2;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "ccx.Crypto:decryptXXTEA",argc, 3);
    return 0;
#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_Crypto_decryptXXTEA'.",&tolua_err);
#endif
    return 0;
}
int lua_lua_gamecore_Crypto_MD5File(lua_State* tolua_S)
{
    int argc = 0;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertable(tolua_S,1,"ccx.Crypto",0,&tolua_err)) goto tolua_lerror;
#endif

    argc = lua_gettop(tolua_S) - 1;

    if (argc == 1)
    {
        const char* arg0;
        std::string arg0_tmp; ok &= luaval_to_std_string(tolua_S, 2, &arg0_tmp, "ccx.Crypto:MD5File"); arg0 = arg0_tmp.c_str();
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_Crypto_MD5File'", nullptr);
            return 0;
        }
        std::string& ret = gamecore::crypto::Crypto::MD5File(arg0);
        lua_pushlstring(tolua_S,ret.c_str(),ret.length());
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "ccx.Crypto:MD5File",argc, 1);
    return 0;
#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_Crypto_MD5File'.",&tolua_err);
#endif
    return 0;
}
int lua_lua_gamecore_Crypto_decodeBase64(lua_State* tolua_S)
{
    int argc = 0;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertable(tolua_S,1,"ccx.Crypto",0,&tolua_err)) goto tolua_lerror;
#endif

    argc = lua_gettop(tolua_S) - 1;

    if (argc == 3)
    {
        const char* arg0;
        int arg1;
        int arg2;
        std::string arg0_tmp; ok &= luaval_to_std_string(tolua_S, 2, &arg0_tmp, "ccx.Crypto:decodeBase64"); arg0 = arg0_tmp.c_str();
        ok &= luaval_to_int32(tolua_S, 3,(int *)&arg1, "ccx.Crypto:decodeBase64");
        ok &= luaval_to_int32(tolua_S, 4,(int *)&arg2, "ccx.Crypto:decodeBase64");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_Crypto_decodeBase64'", nullptr);
            return 0;
        }
        std::string& ret = gamecore::crypto::Crypto::decodeBase64(arg0, arg1, arg2);
        lua_pushlstring(tolua_S,ret.c_str(),ret.length());
        lua_pushinteger(tolua_S, arg2);
        return 2;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "ccx.Crypto:decodeBase64",argc, 3);
    return 0;
#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_Crypto_decodeBase64'.",&tolua_err);
#endif
    return 0;
}
int lua_lua_gamecore_Crypto_encodeBase64(lua_State* tolua_S)
{
    int argc = 0;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertable(tolua_S,1,"ccx.Crypto",0,&tolua_err)) goto tolua_lerror;
#endif

    argc = lua_gettop(tolua_S) - 1;

    if (argc == 3)
    {
        const char* arg0;
        int arg1;
        int arg2;
        std::string arg0_tmp; ok &= luaval_to_std_string(tolua_S, 2, &arg0_tmp, "ccx.Crypto:encodeBase64"); arg0 = arg0_tmp.c_str();
        ok &= luaval_to_int32(tolua_S, 3,(int *)&arg1, "ccx.Crypto:encodeBase64");
        ok &= luaval_to_int32(tolua_S, 4,(int *)&arg2, "ccx.Crypto:encodeBase64");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_Crypto_encodeBase64'", nullptr);
            return 0;
        }
        std::string& ret = gamecore::crypto::Crypto::encodeBase64(arg0, arg1, arg2);
        lua_pushlstring(tolua_S,ret.c_str(),ret.length());
        lua_pushinteger(tolua_S, arg2);
        return 2;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "ccx.Crypto:encodeBase64",argc, 3);
    return 0;
#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_Crypto_encodeBase64'.",&tolua_err);
#endif
    return 0;
}
int lua_lua_gamecore_Crypto_MD5(lua_State* tolua_S)
{
    int argc = 0;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertable(tolua_S,1,"ccx.Crypto",0,&tolua_err)) goto tolua_lerror;
#endif

    argc = lua_gettop(tolua_S) - 1;

    if (argc == 2)
    {
        const char* arg0;
        int arg1;
        std::string arg0_tmp; ok &= luaval_to_std_string(tolua_S, 2, &arg0_tmp, "ccx.Crypto:MD5"); arg0 = arg0_tmp.c_str();
        ok &= luaval_to_int32(tolua_S, 3,(int *)&arg1, "ccx.Crypto:MD5");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_Crypto_MD5'", nullptr);
            return 0;
        }
        std::string& ret = gamecore::crypto::Crypto::MD5(arg0, arg1);
        lua_pushlstring(tolua_S,ret.c_str(),ret.length());
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "ccx.Crypto:MD5",argc, 2);
    return 0;
#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_Crypto_MD5'.",&tolua_err);
#endif
    return 0;
}
static int lua_lua_gamecore_Crypto_finalize(lua_State* tolua_S)
{
    printf("luabindings: finalizing LUA object (Crypto)");
    return 0;
}

int lua_register_lua_gamecore_Crypto(lua_State* tolua_S)
{
    tolua_usertype(tolua_S,"ccx.Crypto");
    tolua_cclass(tolua_S,"Crypto","ccx.Crypto","",nullptr);

    tolua_beginmodule(tolua_S,"Crypto");
        tolua_function(tolua_S,"encryptXXTEA", lua_lua_gamecore_Crypto_encryptXXTEA);
        tolua_function(tolua_S,"decryptXXTEA", lua_lua_gamecore_Crypto_decryptXXTEA);
        tolua_function(tolua_S,"MD5File", lua_lua_gamecore_Crypto_MD5File);
        tolua_function(tolua_S,"decodeBase64", lua_lua_gamecore_Crypto_decodeBase64);
        tolua_function(tolua_S,"encodeBase64", lua_lua_gamecore_Crypto_encodeBase64);
        tolua_function(tolua_S,"MD5", lua_lua_gamecore_Crypto_MD5);
    tolua_endmodule(tolua_S);
    std::string typeName = typeid(gamecore::crypto::Crypto).name();
    g_luaType[typeName] = "ccx.Crypto";
    g_typeCast["Crypto"] = "ccx.Crypto";
    return 1;
}

int lua_lua_gamecore_ResourcesMgr_releaseTextrue(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::ui::ResourcesMgr* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"ccx.ResourcesMgr",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (gamecore::ui::ResourcesMgr*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_lua_gamecore_ResourcesMgr_releaseTextrue'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        std::string arg0;

        ok &= luaval_to_std_string(tolua_S, 2,&arg0, "ccx.ResourcesMgr:releaseTextrue");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_ResourcesMgr_releaseTextrue'", nullptr);
            return 0;
        }
        cobj->releaseTextrue(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "ccx.ResourcesMgr:releaseTextrue",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_ResourcesMgr_releaseTextrue'.",&tolua_err);
#endif

    return 0;
}
int lua_lua_gamecore_ResourcesMgr_removeUnuseResouces(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::ui::ResourcesMgr* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"ccx.ResourcesMgr",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (gamecore::ui::ResourcesMgr*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_lua_gamecore_ResourcesMgr_removeUnuseResouces'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_ResourcesMgr_removeUnuseResouces'", nullptr);
            return 0;
        }
        cobj->removeUnuseResouces();
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "ccx.ResourcesMgr:removeUnuseResouces",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_ResourcesMgr_removeUnuseResouces'.",&tolua_err);
#endif

    return 0;
}
int lua_lua_gamecore_ResourcesMgr_releaseSpriteFramesWithFiles(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::ui::ResourcesMgr* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"ccx.ResourcesMgr",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (gamecore::ui::ResourcesMgr*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_lua_gamecore_ResourcesMgr_releaseSpriteFramesWithFiles'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        std::vector<std::string> arg0;

        ok &= luaval_to_std_vector_string(tolua_S, 2, &arg0, "ccx.ResourcesMgr:releaseSpriteFramesWithFiles");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_ResourcesMgr_releaseSpriteFramesWithFiles'", nullptr);
            return 0;
        }
        cobj->releaseSpriteFramesWithFiles(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "ccx.ResourcesMgr:releaseSpriteFramesWithFiles",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_ResourcesMgr_releaseSpriteFramesWithFiles'.",&tolua_err);
#endif

    return 0;
}
int lua_lua_gamecore_ResourcesMgr_retainTextrue(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::ui::ResourcesMgr* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"ccx.ResourcesMgr",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (gamecore::ui::ResourcesMgr*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_lua_gamecore_ResourcesMgr_retainTextrue'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        std::string arg0;

        ok &= luaval_to_std_string(tolua_S, 2,&arg0, "ccx.ResourcesMgr:retainTextrue");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_ResourcesMgr_retainTextrue'", nullptr);
            return 0;
        }
        cobj->retainTextrue(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "ccx.ResourcesMgr:retainTextrue",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_ResourcesMgr_retainTextrue'.",&tolua_err);
#endif

    return 0;
}
int lua_lua_gamecore_ResourcesMgr_getTextrue(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::ui::ResourcesMgr* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"ccx.ResourcesMgr",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (gamecore::ui::ResourcesMgr*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_lua_gamecore_ResourcesMgr_getTextrue'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        std::string arg0;

        ok &= luaval_to_std_string(tolua_S, 2,&arg0, "ccx.ResourcesMgr:getTextrue");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_ResourcesMgr_getTextrue'", nullptr);
            return 0;
        }
        cocos2d::Texture2D* ret = cobj->getTextrue(arg0);
        object_to_luaval<cocos2d::Texture2D>(tolua_S, "cc.Texture2D",(cocos2d::Texture2D*)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "ccx.ResourcesMgr:getTextrue",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_ResourcesMgr_getTextrue'.",&tolua_err);
#endif

    return 0;
}
int lua_lua_gamecore_ResourcesMgr_retainSpriteFramesWithFile(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::ui::ResourcesMgr* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"ccx.ResourcesMgr",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (gamecore::ui::ResourcesMgr*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_lua_gamecore_ResourcesMgr_retainSpriteFramesWithFile'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        std::string arg0;

        ok &= luaval_to_std_string(tolua_S, 2,&arg0, "ccx.ResourcesMgr:retainSpriteFramesWithFile");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_ResourcesMgr_retainSpriteFramesWithFile'", nullptr);
            return 0;
        }
        cobj->retainSpriteFramesWithFile(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "ccx.ResourcesMgr:retainSpriteFramesWithFile",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_ResourcesMgr_retainSpriteFramesWithFile'.",&tolua_err);
#endif

    return 0;
}
int lua_lua_gamecore_ResourcesMgr_addImageAsyncProgress(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::ui::ResourcesMgr* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"ccx.ResourcesMgr",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (gamecore::ui::ResourcesMgr*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_lua_gamecore_ResourcesMgr_addImageAsyncProgress'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 2) 
    {
        unsigned int arg0;
        std::vector<std::string> arg1;

        arg0 = toluafix_ref_function(tolua_S,2,0);

        ok &= luaval_to_std_vector_string(tolua_S, 3, &arg1, "ccx.ResourcesMgr:addImageAsyncProgress");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_ResourcesMgr_addImageAsyncProgress'", nullptr);
            return 0;
        }
        cobj->addImageAsyncProgress(arg0, arg1);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "ccx.ResourcesMgr:addImageAsyncProgress",argc, 2);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_ResourcesMgr_addImageAsyncProgress'.",&tolua_err);
#endif

    return 0;
}
int lua_lua_gamecore_ResourcesMgr_addImageAsync(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::ui::ResourcesMgr* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"ccx.ResourcesMgr",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (gamecore::ui::ResourcesMgr*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_lua_gamecore_ResourcesMgr_addImageAsync'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 2) 
    {
        unsigned int arg0;
        std::vector<std::string> arg1;

        arg0 = toluafix_ref_function(tolua_S,2,0);

        ok &= luaval_to_std_vector_string(tolua_S, 3, &arg1, "ccx.ResourcesMgr:addImageAsync");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_ResourcesMgr_addImageAsync'", nullptr);
            return 0;
        }
        cobj->addImageAsync(arg0, arg1);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "ccx.ResourcesMgr:addImageAsync",argc, 2);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_ResourcesMgr_addImageAsync'.",&tolua_err);
#endif

    return 0;
}
int lua_lua_gamecore_ResourcesMgr_releaseSpriteFramesWithFile(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::ui::ResourcesMgr* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"ccx.ResourcesMgr",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (gamecore::ui::ResourcesMgr*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_lua_gamecore_ResourcesMgr_releaseSpriteFramesWithFile'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        std::string arg0;

        ok &= luaval_to_std_string(tolua_S, 2,&arg0, "ccx.ResourcesMgr:releaseSpriteFramesWithFile");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_ResourcesMgr_releaseSpriteFramesWithFile'", nullptr);
            return 0;
        }
        cobj->releaseSpriteFramesWithFile(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "ccx.ResourcesMgr:releaseSpriteFramesWithFile",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_ResourcesMgr_releaseSpriteFramesWithFile'.",&tolua_err);
#endif

    return 0;
}
int lua_lua_gamecore_ResourcesMgr_retainSpriteFramesWithFiles(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::ui::ResourcesMgr* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"ccx.ResourcesMgr",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (gamecore::ui::ResourcesMgr*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_lua_gamecore_ResourcesMgr_retainSpriteFramesWithFiles'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        std::vector<std::string> arg0;

        ok &= luaval_to_std_vector_string(tolua_S, 2, &arg0, "ccx.ResourcesMgr:retainSpriteFramesWithFiles");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_ResourcesMgr_retainSpriteFramesWithFiles'", nullptr);
            return 0;
        }
        cobj->retainSpriteFramesWithFiles(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "ccx.ResourcesMgr:retainSpriteFramesWithFiles",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_ResourcesMgr_retainSpriteFramesWithFiles'.",&tolua_err);
#endif

    return 0;
}
int lua_lua_gamecore_ResourcesMgr_addImageSync(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::ui::ResourcesMgr* cobj = nullptr;
    bool ok  = true;
#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"ccx.ResourcesMgr",0,&tolua_err)) goto tolua_lerror;
#endif
    cobj = (gamecore::ui::ResourcesMgr*)tolua_tousertype(tolua_S,1,0);
#if COCOS2D_DEBUG >= 1
    if (!cobj)
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_lua_gamecore_ResourcesMgr_addImageSync'", nullptr);
        return 0;
    }
#endif
    argc = lua_gettop(tolua_S)-1;
    do{
        if (argc == 2) {
            unsigned int arg0;
            arg0 = toluafix_ref_function(tolua_S,2,0);

            if (!ok) { break; }
            std::vector<std::string> arg1;
            ok &= luaval_to_std_vector_string(tolua_S, 3, &arg1, "ccx.ResourcesMgr:addImageSync");

            if (!ok) { break; }
            cobj->addImageSync(arg0, arg1);
            lua_settop(tolua_S, 1);
            return 1;
        }
    }while(0);
    ok  = true;
    do{
        if (argc == 1) {
            std::string arg0;
            ok &= luaval_to_std_string(tolua_S, 2,&arg0, "ccx.ResourcesMgr:addImageSync");

            if (!ok) { break; }
            cobj->addImageSync(arg0);
            lua_settop(tolua_S, 1);
            return 1;
        }
    }while(0);
    ok  = true;
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n",  "ccx.ResourcesMgr:addImageSync",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_ResourcesMgr_addImageSync'.",&tolua_err);
#endif

    return 0;
}
int lua_lua_gamecore_ResourcesMgr_isLoadedSpriteFrame(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::ui::ResourcesMgr* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"ccx.ResourcesMgr",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (gamecore::ui::ResourcesMgr*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_lua_gamecore_ResourcesMgr_isLoadedSpriteFrame'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        std::string arg0;

        ok &= luaval_to_std_string(tolua_S, 2,&arg0, "ccx.ResourcesMgr:isLoadedSpriteFrame");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_ResourcesMgr_isLoadedSpriteFrame'", nullptr);
            return 0;
        }
        bool ret = cobj->isLoadedSpriteFrame(arg0);
        tolua_pushboolean(tolua_S,(bool)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "ccx.ResourcesMgr:isLoadedSpriteFrame",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_ResourcesMgr_isLoadedSpriteFrame'.",&tolua_err);
#endif

    return 0;
}
int lua_lua_gamecore_ResourcesMgr_addSpriteFramesWithFile(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::ui::ResourcesMgr* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"ccx.ResourcesMgr",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (gamecore::ui::ResourcesMgr*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_lua_gamecore_ResourcesMgr_addSpriteFramesWithFile'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        std::string arg0;

        ok &= luaval_to_std_string(tolua_S, 2,&arg0, "ccx.ResourcesMgr:addSpriteFramesWithFile");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_ResourcesMgr_addSpriteFramesWithFile'", nullptr);
            return 0;
        }
        cobj->addSpriteFramesWithFile(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "ccx.ResourcesMgr:addSpriteFramesWithFile",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_ResourcesMgr_addSpriteFramesWithFile'.",&tolua_err);
#endif

    return 0;
}
int lua_lua_gamecore_ResourcesMgr_getSpineSkeletonData(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::ui::ResourcesMgr* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"ccx.ResourcesMgr",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (gamecore::ui::ResourcesMgr*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_lua_gamecore_ResourcesMgr_getSpineSkeletonData'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        std::string arg0;

        ok &= luaval_to_std_string(tolua_S, 2,&arg0, "ccx.ResourcesMgr:getSpineSkeletonData");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_ResourcesMgr_getSpineSkeletonData'", nullptr);
            return 0;
        }
        void* ret = cobj->getSpineSkeletonData(arg0);
        #pragma warning NO CONVERSION FROM NATIVE FOR void*;
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "ccx.ResourcesMgr:getSpineSkeletonData",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_ResourcesMgr_getSpineSkeletonData'.",&tolua_err);
#endif

    return 0;
}
int lua_lua_gamecore_ResourcesMgr_releaseTextrues(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::ui::ResourcesMgr* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"ccx.ResourcesMgr",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (gamecore::ui::ResourcesMgr*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_lua_gamecore_ResourcesMgr_releaseTextrues'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        std::vector<std::string> arg0;

        ok &= luaval_to_std_vector_string(tolua_S, 2, &arg0, "ccx.ResourcesMgr:releaseTextrues");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_ResourcesMgr_releaseTextrues'", nullptr);
            return 0;
        }
        cobj->releaseTextrues(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "ccx.ResourcesMgr:releaseTextrues",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_ResourcesMgr_releaseTextrues'.",&tolua_err);
#endif

    return 0;
}
int lua_lua_gamecore_ResourcesMgr_retainTextrues(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::ui::ResourcesMgr* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"ccx.ResourcesMgr",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (gamecore::ui::ResourcesMgr*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_lua_gamecore_ResourcesMgr_retainTextrues'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        std::vector<std::string> arg0;

        ok &= luaval_to_std_vector_string(tolua_S, 2, &arg0, "ccx.ResourcesMgr:retainTextrues");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_ResourcesMgr_retainTextrues'", nullptr);
            return 0;
        }
        cobj->retainTextrues(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "ccx.ResourcesMgr:retainTextrues",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_ResourcesMgr_retainTextrues'.",&tolua_err);
#endif

    return 0;
}
int lua_lua_gamecore_ResourcesMgr_addSpineSkeletonDataAsyncProgress(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::ui::ResourcesMgr* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"ccx.ResourcesMgr",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (gamecore::ui::ResourcesMgr*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_lua_gamecore_ResourcesMgr_addSpineSkeletonDataAsyncProgress'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 2) 
    {
        unsigned int arg0;
        std::vector<std::string> arg1;

        ok &= luaval_to_uint32(tolua_S, 2,&arg0, "ccx.ResourcesMgr:addSpineSkeletonDataAsyncProgress");

        ok &= luaval_to_std_vector_string(tolua_S, 3, &arg1, "ccx.ResourcesMgr:addSpineSkeletonDataAsyncProgress");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_ResourcesMgr_addSpineSkeletonDataAsyncProgress'", nullptr);
            return 0;
        }
        cobj->addSpineSkeletonDataAsyncProgress(arg0, arg1);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "ccx.ResourcesMgr:addSpineSkeletonDataAsyncProgress",argc, 2);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_ResourcesMgr_addSpineSkeletonDataAsyncProgress'.",&tolua_err);
#endif

    return 0;
}
int lua_lua_gamecore_ResourcesMgr_getProtoData(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::ui::ResourcesMgr* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"ccx.ResourcesMgr",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (gamecore::ui::ResourcesMgr*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_lua_gamecore_ResourcesMgr_getProtoData'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 3) 
    {
        std::string arg0;
        std::string arg1;
        int arg2;

        ok &= luaval_to_std_string(tolua_S, 2,&arg0, "ccx.ResourcesMgr:getProtoData");

        ok &= luaval_to_std_string(tolua_S, 3,&arg1, "ccx.ResourcesMgr:getProtoData");

        ok &= luaval_to_int32(tolua_S, 4,(int *)&arg2, "ccx.ResourcesMgr:getProtoData");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_ResourcesMgr_getProtoData'", nullptr);
            return 0;
        }
        std::string ret = cobj->getProtoData(arg0, arg1, arg2);
        lua_pushlstring(tolua_S,ret.c_str(),ret.length());
        lua_pushinteger(tolua_S, arg2);
        return 2;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "ccx.ResourcesMgr:getProtoData",argc, 3);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_ResourcesMgr_getProtoData'.",&tolua_err);
#endif

    return 0;
}
int lua_lua_gamecore_ResourcesMgr_isSpriteFramesWithFileLoaded(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::ui::ResourcesMgr* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"ccx.ResourcesMgr",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (gamecore::ui::ResourcesMgr*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_lua_gamecore_ResourcesMgr_isSpriteFramesWithFileLoaded'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        std::string arg0;

        ok &= luaval_to_std_string(tolua_S, 2,&arg0, "ccx.ResourcesMgr:isSpriteFramesWithFileLoaded");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_ResourcesMgr_isSpriteFramesWithFileLoaded'", nullptr);
            return 0;
        }
        bool ret = cobj->isSpriteFramesWithFileLoaded(arg0);
        tolua_pushboolean(tolua_S,(bool)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "ccx.ResourcesMgr:isSpriteFramesWithFileLoaded",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_ResourcesMgr_isSpriteFramesWithFileLoaded'.",&tolua_err);
#endif

    return 0;
}
int lua_lua_gamecore_ResourcesMgr_addSpriteFramesWithFiles(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::ui::ResourcesMgr* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"ccx.ResourcesMgr",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (gamecore::ui::ResourcesMgr*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_lua_gamecore_ResourcesMgr_addSpriteFramesWithFiles'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        std::vector<std::string> arg0;

        ok &= luaval_to_std_vector_string(tolua_S, 2, &arg0, "ccx.ResourcesMgr:addSpriteFramesWithFiles");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_ResourcesMgr_addSpriteFramesWithFiles'", nullptr);
            return 0;
        }
        cobj->addSpriteFramesWithFiles(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "ccx.ResourcesMgr:addSpriteFramesWithFiles",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_ResourcesMgr_addSpriteFramesWithFiles'.",&tolua_err);
#endif

    return 0;
}
int lua_lua_gamecore_ResourcesMgr_getFileNameSize(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::ui::ResourcesMgr* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"ccx.ResourcesMgr",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (gamecore::ui::ResourcesMgr*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_lua_gamecore_ResourcesMgr_getFileNameSize'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        std::string arg0;

        ok &= luaval_to_std_string(tolua_S, 2,&arg0, "ccx.ResourcesMgr:getFileNameSize");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_ResourcesMgr_getFileNameSize'", nullptr);
            return 0;
        }
        cocos2d::Size ret = cobj->getFileNameSize(arg0);
        size_to_luaval(tolua_S, ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "ccx.ResourcesMgr:getFileNameSize",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_ResourcesMgr_getFileNameSize'.",&tolua_err);
#endif

    return 0;
}
int lua_lua_gamecore_ResourcesMgr_destroyInstance(lua_State* tolua_S)
{
    int argc = 0;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertable(tolua_S,1,"ccx.ResourcesMgr",0,&tolua_err)) goto tolua_lerror;
#endif

    argc = lua_gettop(tolua_S) - 1;

    if (argc == 0)
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_ResourcesMgr_destroyInstance'", nullptr);
            return 0;
        }
        gamecore::ui::ResourcesMgr::destroyInstance();
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "ccx.ResourcesMgr:destroyInstance",argc, 0);
    return 0;
#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_ResourcesMgr_destroyInstance'.",&tolua_err);
#endif
    return 0;
}
int lua_lua_gamecore_ResourcesMgr_getInstance(lua_State* tolua_S)
{
    int argc = 0;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertable(tolua_S,1,"ccx.ResourcesMgr",0,&tolua_err)) goto tolua_lerror;
#endif

    argc = lua_gettop(tolua_S) - 1;

    if (argc == 0)
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_ResourcesMgr_getInstance'", nullptr);
            return 0;
        }
        gamecore::ui::ResourcesMgr* ret = gamecore::ui::ResourcesMgr::getInstance();
        object_to_luaval<gamecore::ui::ResourcesMgr>(tolua_S, "ccx.ResourcesMgr",(gamecore::ui::ResourcesMgr*)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "ccx.ResourcesMgr:getInstance",argc, 0);
    return 0;
#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_ResourcesMgr_getInstance'.",&tolua_err);
#endif
    return 0;
}
static int lua_lua_gamecore_ResourcesMgr_finalize(lua_State* tolua_S)
{
    printf("luabindings: finalizing LUA object (ResourcesMgr)");
    return 0;
}

int lua_register_lua_gamecore_ResourcesMgr(lua_State* tolua_S)
{
    tolua_usertype(tolua_S,"ccx.ResourcesMgr");
    tolua_cclass(tolua_S,"ResourcesMgr","ccx.ResourcesMgr","cc.Ref",nullptr);

    tolua_beginmodule(tolua_S,"ResourcesMgr");
        tolua_function(tolua_S,"releaseTextrue",lua_lua_gamecore_ResourcesMgr_releaseTextrue);
        tolua_function(tolua_S,"removeUnuseResouces",lua_lua_gamecore_ResourcesMgr_removeUnuseResouces);
        tolua_function(tolua_S,"releaseSpriteFramesWithFiles",lua_lua_gamecore_ResourcesMgr_releaseSpriteFramesWithFiles);
        tolua_function(tolua_S,"retainTextrue",lua_lua_gamecore_ResourcesMgr_retainTextrue);
        tolua_function(tolua_S,"getTextrue",lua_lua_gamecore_ResourcesMgr_getTextrue);
        tolua_function(tolua_S,"retainSpriteFramesWithFile",lua_lua_gamecore_ResourcesMgr_retainSpriteFramesWithFile);
        tolua_function(tolua_S,"addImageAsyncProgress",lua_lua_gamecore_ResourcesMgr_addImageAsyncProgress);
        tolua_function(tolua_S,"addImageAsync",lua_lua_gamecore_ResourcesMgr_addImageAsync);
        tolua_function(tolua_S,"releaseSpriteFramesWithFile",lua_lua_gamecore_ResourcesMgr_releaseSpriteFramesWithFile);
        tolua_function(tolua_S,"retainSpriteFramesWithFiles",lua_lua_gamecore_ResourcesMgr_retainSpriteFramesWithFiles);
        tolua_function(tolua_S,"addImageSync",lua_lua_gamecore_ResourcesMgr_addImageSync);
        tolua_function(tolua_S,"isLoadedSpriteFrame",lua_lua_gamecore_ResourcesMgr_isLoadedSpriteFrame);
        tolua_function(tolua_S,"addSpriteFramesWithFile",lua_lua_gamecore_ResourcesMgr_addSpriteFramesWithFile);
        tolua_function(tolua_S,"getSpineSkeletonData",lua_lua_gamecore_ResourcesMgr_getSpineSkeletonData);
        tolua_function(tolua_S,"releaseTextrues",lua_lua_gamecore_ResourcesMgr_releaseTextrues);
        tolua_function(tolua_S,"retainTextrues",lua_lua_gamecore_ResourcesMgr_retainTextrues);
        tolua_function(tolua_S,"addSpineSkeletonDataAsyncProgress",lua_lua_gamecore_ResourcesMgr_addSpineSkeletonDataAsyncProgress);
        tolua_function(tolua_S,"getProtoData",lua_lua_gamecore_ResourcesMgr_getProtoData);
        tolua_function(tolua_S,"isSpriteFramesWithFileLoaded",lua_lua_gamecore_ResourcesMgr_isSpriteFramesWithFileLoaded);
        tolua_function(tolua_S,"addSpriteFramesWithFiles",lua_lua_gamecore_ResourcesMgr_addSpriteFramesWithFiles);
        tolua_function(tolua_S,"getFileNameSize",lua_lua_gamecore_ResourcesMgr_getFileNameSize);
        tolua_function(tolua_S,"destroyInstance", lua_lua_gamecore_ResourcesMgr_destroyInstance);
        tolua_function(tolua_S,"getInstance", lua_lua_gamecore_ResourcesMgr_getInstance);
    tolua_endmodule(tolua_S);
    std::string typeName = typeid(gamecore::ui::ResourcesMgr).name();
    g_luaType[typeName] = "ccx.ResourcesMgr";
    g_typeCast["ResourcesMgr"] = "ccx.ResourcesMgr";
    return 1;
}

int lua_lua_gamecore_ConfigurationEx_getBoolValue(lua_State* tolua_S)
{
    int argc = 0;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertable(tolua_S,1,"ccx.ConfigurationEx",0,&tolua_err)) goto tolua_lerror;
#endif

    argc = lua_gettop(tolua_S) - 1;

    if (argc == 1)
    {
        std::string arg0;
        ok &= luaval_to_std_string(tolua_S, 2,&arg0, "ccx.ConfigurationEx:getBoolValue");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_ConfigurationEx_getBoolValue'", nullptr);
            return 0;
        }
        bool ret = gamecore::ui::ConfigurationEx::getBoolValue(arg0);
        tolua_pushboolean(tolua_S,(bool)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "ccx.ConfigurationEx:getBoolValue",argc, 1);
    return 0;
#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_ConfigurationEx_getBoolValue'.",&tolua_err);
#endif
    return 0;
}
int lua_lua_gamecore_ConfigurationEx_getIntValue(lua_State* tolua_S)
{
    int argc = 0;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertable(tolua_S,1,"ccx.ConfigurationEx",0,&tolua_err)) goto tolua_lerror;
#endif

    argc = lua_gettop(tolua_S) - 1;

    if (argc == 1)
    {
        std::string arg0;
        ok &= luaval_to_std_string(tolua_S, 2,&arg0, "ccx.ConfigurationEx:getIntValue");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_ConfigurationEx_getIntValue'", nullptr);
            return 0;
        }
        int ret = gamecore::ui::ConfigurationEx::getIntValue(arg0);
        tolua_pushnumber(tolua_S,(lua_Number)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "ccx.ConfigurationEx:getIntValue",argc, 1);
    return 0;
#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_ConfigurationEx_getIntValue'.",&tolua_err);
#endif
    return 0;
}
int lua_lua_gamecore_ConfigurationEx_getStringValue(lua_State* tolua_S)
{
    int argc = 0;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertable(tolua_S,1,"ccx.ConfigurationEx",0,&tolua_err)) goto tolua_lerror;
#endif

    argc = lua_gettop(tolua_S) - 1;

    if (argc == 1)
    {
        std::string arg0;
        ok &= luaval_to_std_string(tolua_S, 2,&arg0, "ccx.ConfigurationEx:getStringValue");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_ConfigurationEx_getStringValue'", nullptr);
            return 0;
        }
        std::string& ret = gamecore::ui::ConfigurationEx::getStringValue(arg0);
        lua_pushlstring(tolua_S,ret.c_str(),ret.length());
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "ccx.ConfigurationEx:getStringValue",argc, 1);
    return 0;
#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_ConfigurationEx_getStringValue'.",&tolua_err);
#endif
    return 0;
}
int lua_lua_gamecore_ConfigurationEx_setDoubleValue(lua_State* tolua_S)
{
    int argc = 0;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertable(tolua_S,1,"ccx.ConfigurationEx",0,&tolua_err)) goto tolua_lerror;
#endif

    argc = lua_gettop(tolua_S) - 1;

    if (argc == 2)
    {
        std::string arg0;
        double arg1;
        ok &= luaval_to_std_string(tolua_S, 2,&arg0, "ccx.ConfigurationEx:setDoubleValue");
        ok &= luaval_to_number(tolua_S, 3,&arg1, "ccx.ConfigurationEx:setDoubleValue");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_ConfigurationEx_setDoubleValue'", nullptr);
            return 0;
        }
        gamecore::ui::ConfigurationEx::setDoubleValue(arg0, arg1);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "ccx.ConfigurationEx:setDoubleValue",argc, 2);
    return 0;
#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_ConfigurationEx_setDoubleValue'.",&tolua_err);
#endif
    return 0;
}
int lua_lua_gamecore_ConfigurationEx_setIntValue(lua_State* tolua_S)
{
    int argc = 0;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertable(tolua_S,1,"ccx.ConfigurationEx",0,&tolua_err)) goto tolua_lerror;
#endif

    argc = lua_gettop(tolua_S) - 1;

    if (argc == 2)
    {
        std::string arg0;
        int arg1;
        ok &= luaval_to_std_string(tolua_S, 2,&arg0, "ccx.ConfigurationEx:setIntValue");
        ok &= luaval_to_int32(tolua_S, 3,(int *)&arg1, "ccx.ConfigurationEx:setIntValue");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_ConfigurationEx_setIntValue'", nullptr);
            return 0;
        }
        gamecore::ui::ConfigurationEx::setIntValue(arg0, arg1);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "ccx.ConfigurationEx:setIntValue",argc, 2);
    return 0;
#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_ConfigurationEx_setIntValue'.",&tolua_err);
#endif
    return 0;
}
int lua_lua_gamecore_ConfigurationEx_getDoubleValue(lua_State* tolua_S)
{
    int argc = 0;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertable(tolua_S,1,"ccx.ConfigurationEx",0,&tolua_err)) goto tolua_lerror;
#endif

    argc = lua_gettop(tolua_S) - 1;

    if (argc == 1)
    {
        std::string arg0;
        ok &= luaval_to_std_string(tolua_S, 2,&arg0, "ccx.ConfigurationEx:getDoubleValue");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_ConfigurationEx_getDoubleValue'", nullptr);
            return 0;
        }
        double ret = gamecore::ui::ConfigurationEx::getDoubleValue(arg0);
        tolua_pushnumber(tolua_S,(lua_Number)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "ccx.ConfigurationEx:getDoubleValue",argc, 1);
    return 0;
#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_ConfigurationEx_getDoubleValue'.",&tolua_err);
#endif
    return 0;
}
int lua_lua_gamecore_ConfigurationEx_setBoolValue(lua_State* tolua_S)
{
    int argc = 0;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertable(tolua_S,1,"ccx.ConfigurationEx",0,&tolua_err)) goto tolua_lerror;
#endif

    argc = lua_gettop(tolua_S) - 1;

    if (argc == 2)
    {
        std::string arg0;
        bool arg1;
        ok &= luaval_to_std_string(tolua_S, 2,&arg0, "ccx.ConfigurationEx:setBoolValue");
        ok &= luaval_to_boolean(tolua_S, 3,&arg1, "ccx.ConfigurationEx:setBoolValue");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_ConfigurationEx_setBoolValue'", nullptr);
            return 0;
        }
        gamecore::ui::ConfigurationEx::setBoolValue(arg0, arg1);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "ccx.ConfigurationEx:setBoolValue",argc, 2);
    return 0;
#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_ConfigurationEx_setBoolValue'.",&tolua_err);
#endif
    return 0;
}
int lua_lua_gamecore_ConfigurationEx_setStringValue(lua_State* tolua_S)
{
    int argc = 0;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertable(tolua_S,1,"ccx.ConfigurationEx",0,&tolua_err)) goto tolua_lerror;
#endif

    argc = lua_gettop(tolua_S) - 1;

    if (argc == 2)
    {
        std::string arg0;
        std::string arg1;
        ok &= luaval_to_std_string(tolua_S, 2,&arg0, "ccx.ConfigurationEx:setStringValue");
        ok &= luaval_to_std_string(tolua_S, 3,&arg1, "ccx.ConfigurationEx:setStringValue");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_ConfigurationEx_setStringValue'", nullptr);
            return 0;
        }
        gamecore::ui::ConfigurationEx::setStringValue(arg0, arg1);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "ccx.ConfigurationEx:setStringValue",argc, 2);
    return 0;
#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_ConfigurationEx_setStringValue'.",&tolua_err);
#endif
    return 0;
}
static int lua_lua_gamecore_ConfigurationEx_finalize(lua_State* tolua_S)
{
    printf("luabindings: finalizing LUA object (ConfigurationEx)");
    return 0;
}

int lua_register_lua_gamecore_ConfigurationEx(lua_State* tolua_S)
{
    tolua_usertype(tolua_S,"ccx.ConfigurationEx");
    tolua_cclass(tolua_S,"ConfigurationEx","ccx.ConfigurationEx","",nullptr);

    tolua_beginmodule(tolua_S,"ConfigurationEx");
        tolua_function(tolua_S,"getBoolValue", lua_lua_gamecore_ConfigurationEx_getBoolValue);
        tolua_function(tolua_S,"getIntValue", lua_lua_gamecore_ConfigurationEx_getIntValue);
        tolua_function(tolua_S,"getStringValue", lua_lua_gamecore_ConfigurationEx_getStringValue);
        tolua_function(tolua_S,"setDoubleValue", lua_lua_gamecore_ConfigurationEx_setDoubleValue);
        tolua_function(tolua_S,"setIntValue", lua_lua_gamecore_ConfigurationEx_setIntValue);
        tolua_function(tolua_S,"getDoubleValue", lua_lua_gamecore_ConfigurationEx_getDoubleValue);
        tolua_function(tolua_S,"setBoolValue", lua_lua_gamecore_ConfigurationEx_setBoolValue);
        tolua_function(tolua_S,"setStringValue", lua_lua_gamecore_ConfigurationEx_setStringValue);
    tolua_endmodule(tolua_S);
    std::string typeName = typeid(gamecore::ui::ConfigurationEx).name();
    g_luaType[typeName] = "ccx.ConfigurationEx";
    g_typeCast["ConfigurationEx"] = "ccx.ConfigurationEx";
    return 1;
}

int lua_lua_gamecore_XClient_isInternetConnectionAvailable(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::net::XClient* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"ccx.XClient",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (gamecore::net::XClient*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_lua_gamecore_XClient_isInternetConnectionAvailable'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_XClient_isInternetConnectionAvailable'", nullptr);
            return 0;
        }
        bool ret = cobj->isInternetConnectionAvailable();
        tolua_pushboolean(tolua_S,(bool)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "ccx.XClient:isInternetConnectionAvailable",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_XClient_isInternetConnectionAvailable'.",&tolua_err);
#endif

    return 0;
}
int lua_lua_gamecore_XClient_http_send(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::net::XClient* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"ccx.XClient",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (gamecore::net::XClient*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_lua_gamecore_XClient_http_send'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 2) 
    {
        unsigned int arg0;
        const char* arg1;

        arg0 = toluafix_ref_function(tolua_S,2,0);

        std::string arg1_tmp; ok &= luaval_to_std_string(tolua_S, 3, &arg1_tmp, "ccx.XClient:http_send"); arg1 = arg1_tmp.c_str();
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_XClient_http_send'", nullptr);
            return 0;
        }
        cobj->http_send(arg0, arg1);
        lua_settop(tolua_S, 1);
        return 1;
    }
    if (argc == 3) 
    {
        unsigned int arg0;
        const char* arg1;
        std::string arg2;

        arg0 = toluafix_ref_function(tolua_S,2,0);

        std::string arg1_tmp; ok &= luaval_to_std_string(tolua_S, 3, &arg1_tmp, "ccx.XClient:http_send"); arg1 = arg1_tmp.c_str();

        ok &= luaval_to_std_string(tolua_S, 4,&arg2, "ccx.XClient:http_send");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_XClient_http_send'", nullptr);
            return 0;
        }
        cobj->http_send(arg0, arg1, arg2);
        lua_settop(tolua_S, 1);
        return 1;
    }
    if (argc == 4) 
    {
        unsigned int arg0;
        const char* arg1;
        std::string arg2;
        const char* arg3;

        arg0 = toluafix_ref_function(tolua_S,2,0);

        std::string arg1_tmp; ok &= luaval_to_std_string(tolua_S, 3, &arg1_tmp, "ccx.XClient:http_send"); arg1 = arg1_tmp.c_str();

        ok &= luaval_to_std_string(tolua_S, 4,&arg2, "ccx.XClient:http_send");

        std::string arg3_tmp; ok &= luaval_to_std_string(tolua_S, 5, &arg3_tmp, "ccx.XClient:http_send"); arg3 = arg3_tmp.c_str();
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_XClient_http_send'", nullptr);
            return 0;
        }
        cobj->http_send(arg0, arg1, arg2, arg3);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "ccx.XClient:http_send",argc, 2);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_XClient_http_send'.",&tolua_err);
#endif

    return 0;
}
int lua_lua_gamecore_XClient_stopMonitorNetwork(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::net::XClient* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"ccx.XClient",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (gamecore::net::XClient*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_lua_gamecore_XClient_stopMonitorNetwork'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_XClient_stopMonitorNetwork'", nullptr);
            return 0;
        }
        cobj->stopMonitorNetwork();
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "ccx.XClient:stopMonitorNetwork",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_XClient_stopMonitorNetwork'.",&tolua_err);
#endif

    return 0;
}
int lua_lua_gamecore_XClient_registerResponseHandler(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::net::XClient* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"ccx.XClient",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (gamecore::net::XClient*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_lua_gamecore_XClient_registerResponseHandler'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        int arg0;

        arg0 = toluafix_ref_function(tolua_S,2,0);
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_XClient_registerResponseHandler'", nullptr);
            return 0;
        }
        cobj->registerResponseHandler(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "ccx.XClient:registerResponseHandler",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_XClient_registerResponseHandler'.",&tolua_err);
#endif

    return 0;
}
int lua_lua_gamecore_XClient_isInternetConnectionWIFI(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::net::XClient* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"ccx.XClient",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (gamecore::net::XClient*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_lua_gamecore_XClient_isInternetConnectionWIFI'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_XClient_isInternetConnectionWIFI'", nullptr);
            return 0;
        }
        bool ret = cobj->isInternetConnectionWIFI();
        tolua_pushboolean(tolua_S,(bool)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "ccx.XClient:isInternetConnectionWIFI",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_XClient_isInternetConnectionWIFI'.",&tolua_err);
#endif

    return 0;
}
int lua_lua_gamecore_XClient_send(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::net::XClient* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"ccx.XClient",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (gamecore::net::XClient*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_lua_gamecore_XClient_send'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 3) 
    {
        unsigned int arg0;
        const char* arg1;
        unsigned int arg2;

        ok &= luaval_to_uint32(tolua_S, 2,&arg0, "ccx.XClient:send");

        std::string arg1_tmp; ok &= luaval_to_std_string(tolua_S, 3, &arg1_tmp, "ccx.XClient:send"); arg1 = arg1_tmp.c_str();

        ok &= luaval_to_uint32(tolua_S, 4,&arg2, "ccx.XClient:send");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_XClient_send'", nullptr);
            return 0;
        }
        unsigned int ret = cobj->send(arg0, arg1, arg2);
        tolua_pushnumber(tolua_S,(lua_Number)ret);
        return 1;
    }
    if (argc == 4) 
    {
        unsigned int arg0;
        const char* arg1;
        unsigned int arg2;
        int arg3;

        ok &= luaval_to_uint32(tolua_S, 2,&arg0, "ccx.XClient:send");

        std::string arg1_tmp; ok &= luaval_to_std_string(tolua_S, 3, &arg1_tmp, "ccx.XClient:send"); arg1 = arg1_tmp.c_str();

        ok &= luaval_to_uint32(tolua_S, 4,&arg2, "ccx.XClient:send");

        ok &= luaval_to_int32(tolua_S, 5,(int *)&arg3, "ccx.XClient:send");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_XClient_send'", nullptr);
            return 0;
        }
        unsigned int ret = cobj->send(arg0, arg1, arg2, arg3);
        tolua_pushnumber(tolua_S,(lua_Number)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "ccx.XClient:send",argc, 3);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_XClient_send'.",&tolua_err);
#endif

    return 0;
}
int lua_lua_gamecore_XClient_setAutoReconnect(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::net::XClient* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"ccx.XClient",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (gamecore::net::XClient*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_lua_gamecore_XClient_setAutoReconnect'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 1) 
    {
        bool arg0;

        ok &= luaval_to_boolean(tolua_S, 2,&arg0, "ccx.XClient:setAutoReconnect");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_XClient_setAutoReconnect'", nullptr);
            return 0;
        }
        cobj->setAutoReconnect(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "ccx.XClient:setAutoReconnect",argc, 1);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_XClient_setAutoReconnect'.",&tolua_err);
#endif

    return 0;
}
int lua_lua_gamecore_XClient_isConnected(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::net::XClient* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"ccx.XClient",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (gamecore::net::XClient*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_lua_gamecore_XClient_isConnected'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_XClient_isConnected'", nullptr);
            return 0;
        }
        bool ret = cobj->isConnected();
        tolua_pushboolean(tolua_S,(bool)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "ccx.XClient:isConnected",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_XClient_isConnected'.",&tolua_err);
#endif

    return 0;
}
int lua_lua_gamecore_XClient_startMonitorNetwork(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::net::XClient* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"ccx.XClient",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (gamecore::net::XClient*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_lua_gamecore_XClient_startMonitorNetwork'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_XClient_startMonitorNetwork'", nullptr);
            return 0;
        }
        cobj->startMonitorNetwork();
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "ccx.XClient:startMonitorNetwork",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_XClient_startMonitorNetwork'.",&tolua_err);
#endif

    return 0;
}
int lua_lua_gamecore_XClient_connect(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::net::XClient* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"ccx.XClient",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (gamecore::net::XClient*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_lua_gamecore_XClient_connect'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 2) 
    {
        const char* arg0;
        unsigned short arg1;

        std::string arg0_tmp; ok &= luaval_to_std_string(tolua_S, 2, &arg0_tmp, "ccx.XClient:connect"); arg0 = arg0_tmp.c_str();

        ok &= luaval_to_ushort(tolua_S, 3, &arg1, "ccx.XClient:connect");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_XClient_connect'", nullptr);
            return 0;
        }
        bool ret = cobj->connect(arg0, arg1);
        tolua_pushboolean(tolua_S,(bool)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "ccx.XClient:connect",argc, 2);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_XClient_connect'.",&tolua_err);
#endif

    return 0;
}
int lua_lua_gamecore_XClient_disconnect(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::net::XClient* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"ccx.XClient",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (gamecore::net::XClient*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_lua_gamecore_XClient_disconnect'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_XClient_disconnect'", nullptr);
            return 0;
        }
        cobj->disconnect();
        lua_settop(tolua_S, 1);
        return 1;
    }
    if (argc == 1) 
    {
        bool arg0;

        ok &= luaval_to_boolean(tolua_S, 2,&arg0, "ccx.XClient:disconnect");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_XClient_disconnect'", nullptr);
            return 0;
        }
        cobj->disconnect(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "ccx.XClient:disconnect",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_XClient_disconnect'.",&tolua_err);
#endif

    return 0;
}
int lua_lua_gamecore_XClient_heartBeatDetection(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::net::XClient* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif


#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertype(tolua_S,1,"ccx.XClient",0,&tolua_err)) goto tolua_lerror;
#endif

    cobj = (gamecore::net::XClient*)tolua_tousertype(tolua_S,1,0);

#if COCOS2D_DEBUG >= 1
    if (!cobj) 
    {
        tolua_error(tolua_S,"invalid 'cobj' in function 'lua_lua_gamecore_XClient_heartBeatDetection'", nullptr);
        return 0;
    }
#endif

    argc = lua_gettop(tolua_S)-1;
    if (argc == 0) 
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_XClient_heartBeatDetection'", nullptr);
            return 0;
        }
        cobj->heartBeatDetection();
        lua_settop(tolua_S, 1);
        return 1;
    }
    if (argc == 1) 
    {
        unsigned short arg0;

        ok &= luaval_to_ushort(tolua_S, 2, &arg0, "ccx.XClient:heartBeatDetection");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_XClient_heartBeatDetection'", nullptr);
            return 0;
        }
        cobj->heartBeatDetection(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    if (argc == 2) 
    {
        unsigned short arg0;
        bool arg1;

        ok &= luaval_to_ushort(tolua_S, 2, &arg0, "ccx.XClient:heartBeatDetection");

        ok &= luaval_to_boolean(tolua_S, 3,&arg1, "ccx.XClient:heartBeatDetection");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_XClient_heartBeatDetection'", nullptr);
            return 0;
        }
        cobj->heartBeatDetection(arg0, arg1);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "ccx.XClient:heartBeatDetection",argc, 0);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_XClient_heartBeatDetection'.",&tolua_err);
#endif

    return 0;
}
int lua_lua_gamecore_XClient_destroyInstance(lua_State* tolua_S)
{
    int argc = 0;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertable(tolua_S,1,"ccx.XClient",0,&tolua_err)) goto tolua_lerror;
#endif

    argc = lua_gettop(tolua_S) - 1;

    if (argc == 0)
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_XClient_destroyInstance'", nullptr);
            return 0;
        }
        gamecore::net::XClient::destroyInstance();
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "ccx.XClient:destroyInstance",argc, 0);
    return 0;
#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_XClient_destroyInstance'.",&tolua_err);
#endif
    return 0;
}
int lua_lua_gamecore_XClient_sleep(lua_State* tolua_S)
{
    int argc = 0;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertable(tolua_S,1,"ccx.XClient",0,&tolua_err)) goto tolua_lerror;
#endif

    argc = lua_gettop(tolua_S) - 1;

    if (argc == 1)
    {
        unsigned int arg0;
        ok &= luaval_to_uint32(tolua_S, 2,&arg0, "ccx.XClient:sleep");
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_XClient_sleep'", nullptr);
            return 0;
        }
        gamecore::net::XClient::sleep(arg0);
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "ccx.XClient:sleep",argc, 1);
    return 0;
#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_XClient_sleep'.",&tolua_err);
#endif
    return 0;
}
int lua_lua_gamecore_XClient_getInstance(lua_State* tolua_S)
{
    int argc = 0;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertable(tolua_S,1,"ccx.XClient",0,&tolua_err)) goto tolua_lerror;
#endif

    argc = lua_gettop(tolua_S) - 1;

    if (argc == 0)
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_XClient_getInstance'", nullptr);
            return 0;
        }
        gamecore::net::XClient* ret = gamecore::net::XClient::getInstance();
        object_to_luaval<gamecore::net::XClient>(tolua_S, "ccx.XClient",(gamecore::net::XClient*)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "ccx.XClient:getInstance",argc, 0);
    return 0;
#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_XClient_getInstance'.",&tolua_err);
#endif
    return 0;
}
static int lua_lua_gamecore_XClient_finalize(lua_State* tolua_S)
{
    printf("luabindings: finalizing LUA object (XClient)");
    return 0;
}

int lua_register_lua_gamecore_XClient(lua_State* tolua_S)
{
    tolua_usertype(tolua_S,"ccx.XClient");
    tolua_cclass(tolua_S,"XClient","ccx.XClient","cc.Ref",nullptr);

    tolua_beginmodule(tolua_S,"XClient");
        tolua_function(tolua_S,"isInternetConnectionAvailable",lua_lua_gamecore_XClient_isInternetConnectionAvailable);
        tolua_function(tolua_S,"http_send",lua_lua_gamecore_XClient_http_send);
        tolua_function(tolua_S,"stopMonitorNetwork",lua_lua_gamecore_XClient_stopMonitorNetwork);
        tolua_function(tolua_S,"registerResponseHandler",lua_lua_gamecore_XClient_registerResponseHandler);
        tolua_function(tolua_S,"isInternetConnectionWIFI",lua_lua_gamecore_XClient_isInternetConnectionWIFI);
        tolua_function(tolua_S,"send",lua_lua_gamecore_XClient_send);
        tolua_function(tolua_S,"setAutoReconnect",lua_lua_gamecore_XClient_setAutoReconnect);
        tolua_function(tolua_S,"isConnected",lua_lua_gamecore_XClient_isConnected);
        tolua_function(tolua_S,"startMonitorNetwork",lua_lua_gamecore_XClient_startMonitorNetwork);
        tolua_function(tolua_S,"connect",lua_lua_gamecore_XClient_connect);
        tolua_function(tolua_S,"disconnect",lua_lua_gamecore_XClient_disconnect);
        tolua_function(tolua_S,"heartBeatDetection",lua_lua_gamecore_XClient_heartBeatDetection);
        tolua_function(tolua_S,"destroyInstance", lua_lua_gamecore_XClient_destroyInstance);
        tolua_function(tolua_S,"sleep", lua_lua_gamecore_XClient_sleep);
        tolua_function(tolua_S,"getInstance", lua_lua_gamecore_XClient_getInstance);
    tolua_endmodule(tolua_S);
    std::string typeName = typeid(gamecore::net::XClient).name();
    g_luaType[typeName] = "ccx.XClient";
    g_typeCast["XClient"] = "ccx.XClient";
    return 1;
}

int lua_lua_gamecore_MessageBox_create(lua_State* tolua_S)
{
    int argc = 0;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertable(tolua_S,1,"ccx.MessageBox",0,&tolua_err)) goto tolua_lerror;
#endif

    argc = lua_gettop(tolua_S) - 1;

    if (argc == 2)
    {
        const char* arg0;
        const char* arg1;
        std::string arg0_tmp; ok &= luaval_to_std_string(tolua_S, 2, &arg0_tmp, "ccx.MessageBox:create"); arg0 = arg0_tmp.c_str();
        std::string arg1_tmp; ok &= luaval_to_std_string(tolua_S, 3, &arg1_tmp, "ccx.MessageBox:create"); arg1 = arg1_tmp.c_str();
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_MessageBox_create'", nullptr);
            return 0;
        }
        gamecore::ui::MessageBox* ret = gamecore::ui::MessageBox::create(arg0, arg1);
        object_to_luaval<gamecore::ui::MessageBox>(tolua_S, "ccx.MessageBox",(gamecore::ui::MessageBox*)ret);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "ccx.MessageBox:create",argc, 2);
    return 0;
#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_MessageBox_create'.",&tolua_err);
#endif
    return 0;
}
int lua_lua_gamecore_MessageBox_constructor(lua_State* tolua_S)
{
    int argc = 0;
    gamecore::ui::MessageBox* cobj = nullptr;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif



    argc = lua_gettop(tolua_S)-1;
    if (argc == 2) 
    {
        const char* arg0;
        const char* arg1;

        std::string arg0_tmp; ok &= luaval_to_std_string(tolua_S, 2, &arg0_tmp, "ccx.MessageBox:MessageBox"); arg0 = arg0_tmp.c_str();

        std::string arg1_tmp; ok &= luaval_to_std_string(tolua_S, 3, &arg1_tmp, "ccx.MessageBox:MessageBox"); arg1 = arg1_tmp.c_str();
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_MessageBox_constructor'", nullptr);
            return 0;
        }
        cobj = new gamecore::ui::MessageBox(arg0, arg1);
        cobj->autorelease();
        int ID =  (int)cobj->_ID ;
        int* luaID =  &cobj->_luaID ;
        toluafix_pushusertype_ccobject(tolua_S, ID, luaID, (void*)cobj,"ccx.MessageBox");
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d \n", "ccx.MessageBox:MessageBox",argc, 2);
    return 0;

#if COCOS2D_DEBUG >= 1
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_MessageBox_constructor'.",&tolua_err);
#endif

    return 0;
}

static int lua_lua_gamecore_MessageBox_finalize(lua_State* tolua_S)
{
    printf("luabindings: finalizing LUA object (MessageBox)");
    return 0;
}

int lua_register_lua_gamecore_MessageBox(lua_State* tolua_S)
{
    tolua_usertype(tolua_S,"ccx.MessageBox");
    tolua_cclass(tolua_S,"MessageBox","ccx.MessageBox","cc.Ref",nullptr);

    tolua_beginmodule(tolua_S,"MessageBox");
        tolua_function(tolua_S,"new",lua_lua_gamecore_MessageBox_constructor);
        tolua_function(tolua_S,"create", lua_lua_gamecore_MessageBox_create);
    tolua_endmodule(tolua_S);
    std::string typeName = typeid(gamecore::ui::MessageBox).name();
    g_luaType[typeName] = "ccx.MessageBox";
    g_typeCast["MessageBox"] = "ccx.MessageBox";
    return 1;
}

int lua_lua_gamecore_WindowSystem_restart(lua_State* tolua_S)
{
    int argc = 0;
    bool ok  = true;

#if COCOS2D_DEBUG >= 1
    tolua_Error tolua_err;
#endif

#if COCOS2D_DEBUG >= 1
    if (!tolua_isusertable(tolua_S,1,"ccx.WindowSystem",0,&tolua_err)) goto tolua_lerror;
#endif

    argc = lua_gettop(tolua_S) - 1;

    if (argc == 0)
    {
        if(!ok)
        {
            tolua_error(tolua_S,"invalid arguments in function 'lua_lua_gamecore_WindowSystem_restart'", nullptr);
            return 0;
        }
        gamecore::ui::WindowSystem::restart();
        lua_settop(tolua_S, 1);
        return 1;
    }
    luaL_error(tolua_S, "%s has wrong number of arguments: %d, was expecting %d\n ", "ccx.WindowSystem:restart",argc, 0);
    return 0;
#if COCOS2D_DEBUG >= 1
    tolua_lerror:
    tolua_error(tolua_S,"#ferror in function 'lua_lua_gamecore_WindowSystem_restart'.",&tolua_err);
#endif
    return 0;
}
static int lua_lua_gamecore_WindowSystem_finalize(lua_State* tolua_S)
{
    printf("luabindings: finalizing LUA object (WindowSystem)");
    return 0;
}

int lua_register_lua_gamecore_WindowSystem(lua_State* tolua_S)
{
    tolua_usertype(tolua_S,"ccx.WindowSystem");
    tolua_cclass(tolua_S,"WindowSystem","ccx.WindowSystem","",nullptr);

    tolua_beginmodule(tolua_S,"WindowSystem");
        tolua_function(tolua_S,"restart", lua_lua_gamecore_WindowSystem_restart);
    tolua_endmodule(tolua_S);
    std::string typeName = typeid(gamecore::ui::WindowSystem).name();
    g_luaType[typeName] = "ccx.WindowSystem";
    g_typeCast["WindowSystem"] = "ccx.WindowSystem";
    return 1;
}
TOLUA_API int register_all_lua_gamecore(lua_State* tolua_S)
{
	tolua_open(tolua_S);
	
	tolua_module(tolua_S,"ccx",0);
	tolua_beginmodule(tolua_S,"ccx");

	lua_register_lua_gamecore_MessageBox(tolua_S);
	lua_register_lua_gamecore_ResourcesMgr(tolua_S);
	lua_register_lua_gamecore_WindowSystem(tolua_S);
	lua_register_lua_gamecore_ConfigurationEx(tolua_S);
	lua_register_lua_gamecore_Crypto(tolua_S);
	lua_register_lua_gamecore_XClient(tolua_S);

	tolua_endmodule(tolua_S);
	return 1;
}

