#pragma once
#include "cocos2d.h"


namespace gamecore {
	namespace crypto {
		class Crypto
		{
		public:
			/** @brief Encrypt data with XXTEA algorithm, return ciphertext, free ciphertext after used */
			static std::string& encryptXXTEA(const char* plaintext,int plaintextLength,int& resultLength);

			/** @brief Decrypt data with XXTEA algorithm, return plaintext, free plaintext after used */
			static std::string& decryptXXTEA(const char* ciphertext, int ciphertextLength, int& resultLength);

			/** @brief Encoding data with Base64 algorithm, return encoded string length */
			static std::string& encodeBase64(const char* input, int inputLength, int& outputBufferLength);


			/** @brief Decoding Base64 string to data, return decoded data length */
			static std::string& decodeBase64(const char* input, int inputLength, int& outputBufferLength);

			/** @brief Calculate MD5, get MD5 code */
			static std::string& MD5(const char* input, int inputLength);

			static std::string& MD5File(const char* path);

		};
	}
}

