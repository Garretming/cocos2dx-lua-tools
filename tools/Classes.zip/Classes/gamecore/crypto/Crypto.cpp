
#include "Crypto.h"
#include "xxtea/xxtea.h"
#include "base/base64.h"
#include "md5/md5.h"
#include "../gamecore.h"

namespace gamecore {
	namespace crypto {

		static std::string m_string = "";
		std::string& Crypto::encryptXXTEA(const char* plaintext, int plaintextLength, int& resultLength)
		{
			xxtea_long len;
			unsigned char* result = xxtea_encrypt((unsigned char*) plaintext, (xxtea_long)plaintextLength, (unsigned char*)xxtea_key, (xxtea_long)xxtea_key_len, &len);
			resultLength = (int)len;

			m_string = "";
			m_string.assign((const char*)result, len);
			free(result);
			return m_string;
		}

		std::string& Crypto::decryptXXTEA(const char* ciphertext, int ciphertextLength, int& resultLength)
		{
			xxtea_long len;
			unsigned char* result = xxtea_decrypt((unsigned char*)ciphertext, (xxtea_long)ciphertextLength, (unsigned char*)xxtea_key, (xxtea_long)xxtea_key_len, &len);
			resultLength = (int)len;

			m_string = "";
			m_string.assign((const char*)result, len);
			free(result);
			return m_string;
		}


		std::string& Crypto::encodeBase64(const char* input, int inputLength, int& outputBufferLength)
		{
			char* result = (char *)malloc((inputLength + 2) / 3 * 4 + 1);

			int len = cocos2d::base64Encode((const unsigned char*)input, inputLength, &result);
			outputBufferLength = len;

			m_string = "";
			m_string.assign((const char*)result, len);
			free(result);
			return m_string;
		}


		std::string& Crypto::decodeBase64(const char* input, int inputLength, int& outputBufferLength)
		{
			unsigned char* result = (unsigned char *)malloc(inputLength + 1);

			int len = cocos2d::base64Decode((const unsigned char*)input, inputLength, &result);
			outputBufferLength = len;

			m_string = "";
			m_string.assign((const char*)result, len);
			free(result);
			return m_string;
		}


		std::string& Crypto::MD5(const char* input, int inputLength)
		{
			cocos2d::Data data;
			data.copy((unsigned char*)input, inputLength);
			m_string = "";
			m_string = cocos2d::utils::getDataMD5Hash(data);

			return m_string;
		}

		std::string& Crypto::MD5File(const char* path)
		{
			m_string = "";
			m_string = cocos2d::utils::getFileMD5Hash(path);

			return m_string;
		}

		

	}
}

