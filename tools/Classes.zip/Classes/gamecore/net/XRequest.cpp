
#include "XRequest.h"
#include "XNetMacros.h"
#include <string>
namespace gamecore{
    namespace net
    {
        XRequest::XRequest(uint32_t opcode,uint32_t serialNumber, const char* pData, uint32_t len)
        :m_opcode(opcode),
        _pData(nullptr),
        _serialNumber(serialNumber),
        _pOriginalData(nullptr)
        {
            _datalen = len + PACKAGE_HEAD_LEN;
            _pData = new char[_datalen];
            
            *(uint32_t*)(_pData)       = htonl(len + 8);               //数据长度
            *(uint32_t*)(_pData+4)     = htonl(opcode);                //指令id
            *(uint32_t*)(_pData+8)     = htonl(serialNumber);          //指令序列号,服务端原样返回，如果是notify指令，可默认0
            if (len > 0)
            {
                memcpy(_pData+PACKAGE_HEAD_LEN, pData, len);
                _pOriginalData = new char[len];
                memcpy(_pOriginalData, pData, len);
            }
        }
        
        XRequest::~XRequest(void)
        {
            if (_pData)
            {
                delete [] _pData;
                _pData = nullptr;
            }
            if (_pOriginalData)
            {
                delete [] _pOriginalData;
                _pOriginalData = nullptr;
            }
            
        }
    }
}
