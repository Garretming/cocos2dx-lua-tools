

#pragma once

#include <stdio.h>

namespace gamecore{
    namespace net {
        class NetworkMonitor{
        protected:
            NetworkMonitor(){}
            virtual ~NetworkMonitor(){}
        public:
            static bool isInternetConnectionAvailable();
            static bool isInternetConnectionWIFI();
            
            static void start();
            static void stop();
        };
    }
}


