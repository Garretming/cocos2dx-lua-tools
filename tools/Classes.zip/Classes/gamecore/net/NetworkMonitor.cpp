#include "NetworkMonitor.h"
#include "cocos2d.h"
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS) || (CC_TARGET_PLATFORM == CC_PLATFORM_MAC)
#include "ios/NetworkMonitorIOS.h"
#elif (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
#include "android/NetworkMonitorAndroid.h"
#endif


namespace gamecore {
    namespace net {
        bool NetworkMonitor::isInternetConnectionAvailable()
        {
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
            return true;
#elif (CC_TARGET_PLATFORM == CC_PLATFORM_IOS) || (CC_TARGET_PLATFORM == CC_PLATFORM_MAC)
            return NetworkMonitorIOS::isInternetConnectionAvailable();
#elif (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
            return NetworkMonitorAndroid::isInternetConnectionAvailable();
#endif
            return true;
        }
        
        bool NetworkMonitor::isInternetConnectionWIFI()
        {
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
            return true;
#elif (CC_TARGET_PLATFORM == CC_PLATFORM_IOS) || (CC_TARGET_PLATFORM == CC_PLATFORM_MAC)
            return NetworkMonitorIOS::isInternetConnectionWIFI();
#elif (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
            return NetworkMonitorAndroid::isInternetConnectionWIFI();
#endif
            return true;
        }
        
        void NetworkMonitor::start()
        {
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)

#elif (CC_TARGET_PLATFORM == CC_PLATFORM_IOS) || (CC_TARGET_PLATFORM == CC_PLATFORM_MAC)
            return NetworkMonitorIOS::start();
#elif (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
            return NetworkMonitorAndroid::start();
#endif
        }
        
        void NetworkMonitor::stop()
        {
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
#elif (CC_TARGET_PLATFORM == CC_PLATFORM_IOS) || (CC_TARGET_PLATFORM == CC_PLATFORM_MAC)
            return NetworkMonitorIOS::stop();
#elif (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
            return NetworkMonitorAndroid::stop();
#endif
        }

    }
}
