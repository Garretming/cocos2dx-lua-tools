

#pragma once

#include <stdio.h>
#include "XNetMacros.h"
#include "XInetAddress.h"
namespace gamecore{
    namespace net {
        enum XSocketStatus
        {
            eSocketConnected			=  1,
            eSocketConnecting			=  2,
            eSocketDisconnected			=  3,
            eSocketConnectTimeout		=  4,
            eSocketReceive				=  5,
            eSocketIoClosed				=  0,
            eSocketIoError				= -1,
            eSocketCreateFailed			= -2,
        };

        class XSocket
        {
        public:
            XSocket();
            virtual ~XSocket();
            bool netInit();
            int32_t  netRead(char* _buff, size_t _len);
            int32_t  netWrite(char* _buff, size_t _len);
            
            bool netIsConnected();
            bool netIsReadable();
            bool netIsWritable();
            void netClose();
            bool netConnect();
            void netDisconnect();
            void setInetAddress(const XInetAddress& oInetAddress);
            SOCKET getSocketID(){return m_uSocket;}
        protected:
            XSocketStatus m_socketStatus;
            SOCKET m_uSocket;
            XInetAddress m_oInetAddress;
        };
    }
}

