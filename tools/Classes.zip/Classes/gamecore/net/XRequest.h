#pragma once

#include "cocos2d.h"
#include "XNetMacros.h"
namespace gamecore{
    namespace net
    {
        class XRequest : public cocos2d::Ref
        {
        public:
            XRequest(uint32_t opcode,uint32_t serialNumber, const char* pData, uint32_t len);
            virtual ~XRequest(void);

        // method
        public:
            char* getData() {return _pData;};
            uint32_t getDataLength() {return _datalen;}
            uint32_t getOpCode(){return _opcode;}
            uint32_t getSerialNumber() {return _serialNumber;}
            char* getOriginalData() {return _pOriginalData;}
        private:
            char* _pData;
            char* _pOriginalData;
            uint32_t _opcode;
            uint32_t _serialNumber;
            uint32_t _datalen;
        };
    }
}


