
#pragma once

#include <stdio.h>
#include "cocos2d.h"
#include "XRequest.h"
#include "XSocket.h"
#include "XEvent.h"
#include "network/HttpRequest.h"
#include "network/HttpResponse.h"
#include "network/HttpClient.h"
#include <vector>
#include <unordered_map>
#include "NetworkMonitor.h"
using namespace cocos2d;

namespace gamecore{
    namespace net {
        class XClient:public cocos2d::Ref{
        protected:
            XClient();
            virtual ~XClient();
            bool init();
        public:
            static XClient* getInstance();
            static void destroyInstance();
            static void sleep(uint32_t ms);
            void setAutoReconnect(bool bValue){m_isAutoReconnect = bValue;}
            bool connect(const char* ip, unsigned short port);
            void disconnect(bool manual = false);
            bool isConnected(){ return m_oSocket.netIsConnected();}

            uint32_t send(uint32_t opcode, const char* msg, uint32_t len, int32_t index=-1);
            void http_send(uint32_t nHandler,const char* url,const std::string& postData="", const char* remark = nullptr);
			void http_send_c(const cocos2d::network::ccHttpRequestCallback& callback, const char* url, const std::string& postData = "", const char* remark = nullptr);

            void registerResponseHandler(int nHandler){m_HandlerNumber = nHandler;}

            void heartBeatDetection(unsigned short time=SOCKET_SOTIMEOUT, bool isRightNow = false);
            bool isInternetConnectionAvailable();
            bool isInternetConnectionWIFI();
            
            void startMonitorNetwork();
            void stopMonitorNetwork();
            
        protected:
            uint32_t getNextSerialNumber(){return ++m_SerialNumber;}
            void run();
            void onConnected();
            bool connect();
            void onDisconnected();
            void runRead();
            void runWrite();
            void runScheduleEventDispatcher(float dt);
            void runScheduleSendHeartBeatPackage(float dt);
            void addEvent(gamecore::net::XEvent* event);
            int  executeResponseCallback(uint32_t opcode,uint32_t serialNumbe,char* pData, uint32_t len);
            void httpRequestCallback(cocos2d::network::HttpClient* client, cocos2d::network::HttpResponse* response);

            void internetDisconnectionEvent(cocos2d::EventCustom* event);
        private:
            bool                                m_isInited;
            bool                                m_isNetThreadRunning;
            bool                                m_isDispatchConnect;
            static XClient*                     m_Instance;
			int                                 m_HandlerNumber;
            std::mutex                          m_RequestQueueMutex;
            std::mutex                          m_ReceiveQueueMutex;
            Vector<XRequest*>                   m_RequestVec;
            Vector<XEvent*>                     m_EventVec;
            XRequest*                           m_CurrentRequestData;
            uint32_t                            m_SendIndex;
            uint16_t                            m_HeaderIndex;
            char                                m_Header[PACKAGE_HEAD_LEN];
            uint32_t                            m_CmdId;
            uint32_t                            m_ReceiveMaxSize;
            char*                               m_ReceiveBuf;
            uint32_t                            m_ReceiveIndex;  //接收的索引
            uint32_t                            m_ReceiveLength;  // 需要接收的数据长度
            XSocket                             m_oSocket;
            std::string                         m_ip;
            uint16_t                            m_port;
            bool                                m_isAutoReconnect;          //是否自动重连,默认true
            uint16_t                            m_currentReconnectTimes;    //当前重连的次数
            std::unordered_map<uint32_t,size_t> m_SendHeartBeatTimeMap;        //开始发送心跳包的时间
            uint32_t                            m_SerialNumber;             //指令序列号，唯一标志每条指令
            std::thread*                        m_NetThread;
            cocos2d::Vector<XRequest*>          m_unresponseRequest;
        };
    }
}


