
#include "XEvent.h"

namespace gamecore{
    namespace net
    {
        XEvent::XEvent(uint32_t opcode, uint32_t serialNumber,char* pData, uint32_t len)
            : _pData(nullptr)
            , _opcode(opcode)
            , _datalen(len)
            , _serialNumber(serialNumber)
        {
            if (_datalen > 0)
            {
                _pData = new char[m_datalen];
                memcpy(_pData, pData, _datalen);
            }
        }

        XEvent::~XEvent(void)
        {
            if (_pData)
            {
                delete [] _pData;
                _pData = nullptr;
            }
        }
    }
}


