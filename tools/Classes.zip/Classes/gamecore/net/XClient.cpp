
#include "XClient.h"
#include "scripting/lua-bindings/manual/CCLuaEngine.h"
#include "NetworkMonitor.h"

namespace gamecore{
    namespace net {
		XClient* XClient::m_Instance = NULL;
        XClient::XClient():
        m_ip(""),
        m_port(0),
        m_CurrentRequestData(NULL),
        m_SendIndex(0),
        m_HeaderIndex(0),
        m_CmdId(0),
        m_ReceiveMaxSize(SEND_BYTES * 16),
        m_ReceiveIndex(0),
        m_ReceiveLength(0),
		m_HandlerNumber(0),
        m_isAutoReconnect(true),
        m_currentReconnectTimes(0),
        m_SerialNumber(100),
        m_isInited(false),
        m_isNetThreadRunning(false),
        m_isDispatchConnect(false),
		m_NetThread(nullptr)
        {
        }
        XClient::~XClient()
        {
            cocos2d::Director::getInstance()->getScheduler()->unscheduleAllForTarget(this);
            cocos2d::Director::getInstance()->getEventDispatcher()->removeCustomEventListeners("EVENT_INTERNET_DISCONNECT");
			if (m_NetThread) m_NetThread->join();
			CC_SAFE_DELETE(m_NetThread);
        }

        XClient* XClient::getInstance()
        {
            if (NULL == m_Instance) {
				m_Instance = new XClient();
				m_Instance->init();
            }
			return m_Instance;
        }

        void XClient::destroyInstance()
        {
			if (m_Instance) {
				delete m_Instance;
				m_Instance = NULL;
            }
        }

        bool XClient::init()
        {
            if (m_isInited) {
                return true;
            }
            
			m_RequestVec.clear();
            m_EventVec.clear();
            m_ReceiveBuf = (char*) malloc(sizeof(char) * m_ReceiveMaxSize);
            
			m_NetThread = new std::thread(&XClient::run, this);
            
            cocos2d::Director::getInstance()->getEventDispatcher()->addCustomEventListener("EVENT_INTERNET_DISCONNECT", std::bind(&XClient::internetDisconnectionEvent,this,std::placeholders::_1));

            cocos2d::Director::getInstance()->getScheduler()->schedule(CC_SCHEDULE_SELECTOR(XClient::runScheduleEventDispatcher), this, 0, false);
            
            m_isInited = true;
            return true;
        }

        void XClient::run()
        {
            while (1)
            {
                
                if (!m_isInited || !m_isNetThreadRunning) {
                    goto LOOP;
                }
                
                if (m_oSocket.netIsConnected()) {
                    //第一次连接成功发送 onConnect事件
                    if (!m_isDispatchConnect) {
                        m_isDispatchConnect = true;
                        m_currentReconnectTimes = 0;
                        
                        m_ReceiveQueueMutex.lock();
                        m_EventVec.clear();
                        m_ReceiveQueueMutex.unlock();
                        
                        onConnected();
                    }

                    bool bWrite = false;
                    m_ReceiveQueueMutex.lock();
					if (m_RequestVec.size() > 0)
                    {
                        bWrite = true;
                    }
                    m_ReceiveQueueMutex.unlock();

					if (m_oSocket.netIsReadable() || m_Instance->m_HeaderIndex > 0)
                    {
                        runRead();
                    }

                    if (bWrite && m_oSocket.netIsWritable()) {
                        runWrite();
                    }
                }
                else
                {
                    disconnect(true);
                    m_isDispatchConnect = false;
                    if (m_isAutoReconnect) {
                        if (m_currentReconnectTimes < RECONNECT_MAX_TIMES) {
                            connect();
                            ++ m_currentReconnectTimes;
                            XClient::sleep(CONNECT_TIME_OUT_INTERVAL);
                        }
                        else
                        {
                            m_currentReconnectTimes = 0;
                            XEvent* event = new XEvent(CMDID_RECONNECT_FAILED,0,NULL,0);
                            addEvent(event);
                            event->release();
                        }
                    }
                }

            LOOP:
                XClient::sleep(30);
            }
        }

        void XClient::runRead()
        {
            int32_t ret = 0;
            if (m_HeaderIndex < PACKAGE_HEAD_LEN) // 未接收完整头部
            {
                ret = m_oSocket.netRead((char*)&m_Header[m_HeaderIndex], PACKAGE_HEAD_LEN - m_HeaderIndex);
                if (ret > 0)
                {
                    m_HeaderIndex += ret;
                }
                else if (ret < 0)
                {
                    disconnect();
                    return;
                }
            }
            else
            {
                if (m_ReceiveLength == 0 && m_ReceiveIndex == 0 && m_CmdId == 0) // 未读取数据包头
                {
                    m_CmdId = ntohl(*(uint32_t*)&m_Header[4]);
                    m_ReceiveLength = ntohl(*(uint32_t*)&m_Header) - 8;
                    if (m_ReceiveLength > m_ReceiveMaxSize)
                    {
                        m_ReceiveMaxSize = (m_ReceiveLength / SEND_BYTES + 1) * SEND_BYTES;
                        m_ReceiveBuf = (char*)realloc(m_ReceiveBuf, m_ReceiveMaxSize);
                    }
                }

				if (m_ReceiveLength - m_ReceiveIndex > 0)
				{
					ret = m_oSocket.netRead(&m_ReceiveBuf[m_ReceiveIndex], m_ReceiveLength - m_ReceiveIndex);
					if (ret > 0)
					{
						m_ReceiveIndex += ret;
					}
					else if (ret <= -1)
					{
						disconnect();
						return;
					}
				}
                
                if (m_ReceiveIndex == m_ReceiveLength)
                {
                    uint32_t serialNumber = ntohl(*(uint32_t*)&m_Header[8]);
                    XEvent* event = new XEvent(m_CmdId,serialNumber,m_ReceiveBuf,m_ReceiveLength);

                    //ping指令直接截断，不进行事件分发;如果超时,分发disconnect 事件
                    if (m_CmdId == CMDID_HEART_BEAT_PING) {
						std::unordered_map<uint32_t, size_t>::iterator findIterator = m_SendHeartBeatTimeMap.find(serialNumber);
						if (findIterator != m_SendHeartBeatTimeMap.end()) {
                            struct timeval stCurrentTime;
                            gettimeofday(&stCurrentTime,NULL);
                            size_t receiveTime = stCurrentTime.tv_sec*1000+stCurrentTime.tv_usec*0.001;
                            size_t triggerTime = findIterator->second;
                            
                            cocos2d::log("ping time = %lu", receiveTime - triggerTime);
                            //超时
                            if ((receiveTime - triggerTime)/1000 > SOCKET_SOTIMEOUT) {
                                disconnect();
                            }

							m_SendHeartBeatTimeMap.erase(findIterator);
                        }
                    }
                    else
                    {
                        this->addEvent(event);
                    }
                    event->release();

                    // 重置
                    m_HeaderIndex = 0;
                    m_ReceiveLength = 0;
                    m_ReceiveIndex = 0;
                    m_CmdId = 0;
                }
            }
        }

        void XClient::addEvent(gamecore::net::XEvent *event)
        {
            m_ReceiveQueueMutex.lock();
            m_EventVec.pushBack(event);
            m_ReceiveQueueMutex.unlock();
        }

        void XClient::runWrite()
        {
            if (m_CurrentRequestData == NULL)
            {
                m_RequestQueueMutex.lock();
				if (m_RequestVec.size() > 0)
                {
					m_CurrentRequestData = m_RequestVec.at(0);
                    m_SendIndex = 0;
                }
                m_RequestQueueMutex.unlock();
            }

            if (m_CurrentRequestData->getOpCode() == CMDID_HEART_BEAT_PING) {
                struct timeval stCurrentTime;
                gettimeofday(&stCurrentTime,NULL);

                size_t triggerTime = stCurrentTime.tv_sec*1000+stCurrentTime.tv_usec*0.001; //millseconds
				m_SendHeartBeatTimeMap.insert(std::make_pair(m_CurrentRequestData->getSerialNumber(), triggerTime));
            }
            // 发送数据包
            char* buf = m_CurrentRequestData->getData();
			uint32_t datalen = m_CurrentRequestData->getDataLength();
            uint32_t totalBytes = datalen - m_SendIndex;
            
            do
            {
                int32_t ret = m_oSocket.netWrite(&buf[m_SendIndex],totalBytes>SEND_BYTES?SEND_BYTES:totalBytes);
                if (ret > 0) {
                    m_SendIndex += ret;
                    totalBytes -= ret;
                }
                else if(ret <= 0)
                {
                    disconnect();
                    return;
                }
            } while(m_SendIndex < datalen);

            
            // 发送完成
            if (m_SendIndex >= datalen)
            {
                m_RequestQueueMutex.lock();
				if (m_RequestVec.size() > 0) {
					m_RequestVec.eraseObject(m_CurrentRequestData);
                }
                m_RequestQueueMutex.unlock();
                m_CurrentRequestData = NULL;
            }
        }


        void XClient::sleep(uint32_t ms)
        {
    #ifdef _WIN32
            Sleep(ms);
    #else
            struct timespec req;
            req.tv_nsec = ms%1000;
            req.tv_sec = (ms-req.tv_nsec)/1000;
            req.tv_nsec = req.tv_nsec*1000000;
            struct timespec rem;
            nanosleep(&req, &rem);
    #endif
        }

        void XClient::onConnected()
        {
            XEvent* event = new XEvent(CMDID_CONNECTED,0,NULL,0);
            this->addEvent(event);
            event->release();
        }

        void XClient::onDisconnected()
        {
            XEvent* event = new XEvent(CMDID_DISCONNECTED,0,NULL,0);
            this->addEvent(event);
            event->release();
        }

        void XClient::disconnect(bool manual)
        {
            if (m_RequestQueueMutex.try_lock()) {
				m_RequestVec.clear();
                m_RequestQueueMutex.unlock();
            }
            
            if(m_ReceiveQueueMutex.try_lock())
            {
                m_EventVec.clear();
                m_ReceiveQueueMutex.unlock();
            }
            
            Director::getInstance()->getScheduler()->unschedule(CC_SCHEDULE_SELECTOR(XClient::runScheduleSendHeartBeatPackage), this);
            
            if (m_oSocket.getSocketID() != INVALID_SOCKET) {
                m_isNetThreadRunning = false;
                m_isDispatchConnect = false;
                m_oSocket.netDisconnect();
                if (!manual) {
                    onDisconnected();
                }
            }
        }


        bool XClient::connect()
        {
            return this->connect(m_ip.c_str(),m_port);
        }

        bool XClient::connect(const char* ip, unsigned short port)
        {
            XInetAddress oAddres;
            oAddres.setIp(ip);
            oAddres.setPort(port);
            m_ip = ip;
            m_port = port;

            m_oSocket.setInetAddress(oAddres);
            bool isConnect = false;
            if( m_oSocket.netConnect() )
            {
                isConnect = true;
            }
            
            m_isNetThreadRunning = true;
            return isConnect;
        }
        uint32_t XClient::send(uint32_t opcode, const char *msg, uint32_t len,int32_t index)
        {
            uint32_t serialNumber = this->getNextSerialNumber();
            XRequest* request = new XRequest(opcode, serialNumber, msg, len);
            m_RequestQueueMutex.lock();
            if (index == -1)
            {
				m_RequestVec.pushBack(request);
            }
            else
            {
				m_RequestVec.insert(index, request);
            }
            m_RequestQueueMutex.unlock();
            
            request->release();
            return serialNumber;
        }
        
        //分发响应事件到lua
        void XClient::runScheduleEventDispatcher(float t)
        {
            m_ReceiveQueueMutex.lock();

            for (int i=0; i<m_EventVec.size(); ++i) {
				XEvent* event = m_EventVec.at(i);
                uint32_t opCode = event->getOpCode();
                uint32_t datalen = event->getDataLength();
                char* data = event->getData();
                executeResponseCallback(opCode,event->getSerialNumber(),data,datalen);
            }
            
			m_EventVec.clear();
            
            m_ReceiveQueueMutex.unlock();
        }

		int XClient::executeResponseCallback(uint32_t opcode, uint32_t serialNumber, char* pData, uint32_t len)
        {
			if (m_HandlerNumber)
            {
                LuaEngine* engine = (LuaEngine*)ScriptEngineManager::getInstance()->getScriptEngine();
                LuaStack* p = engine->getLuaStack();
                p->pushLong(opcode);
                p->pushLong(serialNumber);
                p->pushString((const char*)pData, len);
                p->pushLong(len);
				return p->executeFunctionByHandler(m_HandlerNumber, 4);
            }
            return 0;
        }

        void XClient::heartBeatDetection(unsigned short time, bool isRightNow)
        {
            Director::getInstance()->getScheduler()->schedule(CC_SCHEDULE_SELECTOR(XClient::runScheduleSendHeartBeatPackage), this, time, false);
            if (isRightNow) {
                this->runScheduleSendHeartBeatPackage(0);
            }
        }

        void XClient::runScheduleSendHeartBeatPackage(float t)
        {
            this->send(CMDID_HEART_BEAT_PING, NULL, 0);
        }

		void XClient::http_send(uint32_t nHandler, const char* url, const std::string& postData, const char* remark)
        {
			cocos2d::network::HttpRequest *request = new cocos2d::network::HttpRequest();
			request->setUrl(url);
			if (postData.empty()) {
				request->setRequestType(cocos2d::network::HttpRequest::Type::GET);
			}
			else
			{
				request->setRequestData(postData.c_str(), postData.size());
				request->setRequestType(cocos2d::network::HttpRequest::Type::POST);
			}

			std::stringstream tag("");

			tag << nHandler;
			
			if (nullptr != remark)
			{
				tag << "#####";
				tag << remark;
			}
			request->setTag(tag.str());

			request->setResponseCallback(std::bind(&XClient::httpRequestCallback, this, std::placeholders::_1, std::placeholders::_2));
			cocos2d::network::HttpClient::getInstance()->send(request);

			request->release();
        }
        
        void XClient::http_send_c(const cocos2d::network::ccHttpRequestCallback &callback, const char *url, const std::string& postData, const char* remark)
		{

			cocos2d::network::HttpRequest *request = new cocos2d::network::HttpRequest();
			request->setUrl(url);
			if (postData.empty()) {
				request->setRequestType(cocos2d::network::HttpRequest::Type::GET);
			}
			else
			{
				request->setRequestData(postData.c_str(), postData.size());
				request->setRequestType(cocos2d::network::HttpRequest::Type::POST);
			}

			if (remark != nullptr)
			{
				request->setTag(remark);
			}
			request->setResponseCallback(callback);
			cocos2d::network::HttpClient::getInstance()->send(request);

			request->release();
        }
        
        void XClient::httpRequestCallback(cocos2d::network::HttpClient *client, cocos2d::network::HttpResponse *response)
        {
            std::string tag = response->getHttpRequest()->getTag();

			size_t pos = tag.find("#####");
			long handler = atol(tag.substr(0, pos).c_str());
			std::string remark = tag.substr(pos + 5);
            if (handler) {
                LuaEngine* engine = (LuaEngine*)ScriptEngineManager::getInstance()->getScriptEngine();
                LuaStack* p = engine->getLuaStack();
                
                
                LuaValueDict data;
                std::string responseData = "";
                responseData.assign(response->getResponseData()->begin(), response->getResponseData()->end());
                
                data.insert(data.end(), LuaValueDict::value_type("code", LuaValue::intValue((int)response->getResponseCode())));
                data.insert(data.end(), LuaValueDict::value_type("data", LuaValue::stringValue(responseData)));
                data.insert(data.end(), LuaValueDict::value_type("size", LuaValue::intValue((int)response->getResponseData()->size())));
                data.insert(data.end(), LuaValueDict::value_type("error", LuaValue::stringValue(response->getErrorBuffer())));
                
                p->pushLuaValueDict(data);
				p->pushString(remark.c_str(), remark.length());

				p->executeFunctionByHandler((int)handler, 2);
                
				p->removeScriptHandler((int)handler);
            }
            
        }

        bool XClient::isInternetConnectionAvailable()
        {
            return gamecore::net::NetworkMonitor::isInternetConnectionAvailable();
        }
        
        bool XClient::isInternetConnectionWIFI()
        {
            return gamecore::net::NetworkMonitor::isInternetConnectionWIFI();
        }
        

        void XClient::internetDisconnectionEvent(cocos2d::EventCustom* event)
        {
            if ("EVENT_INTERNET_DISCONNECT" == event->getEventName()) {
                disconnect();
            }
        }
        
        void XClient::startMonitorNetwork()
        {
            gamecore::net::NetworkMonitor::start();
        }
        
        void XClient::stopMonitorNetwork()
        {
            gamecore::net::NetworkMonitor::stop();
        }

    }
}
