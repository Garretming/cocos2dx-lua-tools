﻿
#ifndef __XNET_MACROS_H__
#define __XNET_MACROS_H__

#include "cocos2d.h"


#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS || CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
#ifndef INVALID_SOCKET
#define INVALID_SOCKET  (SOCKET)(0)
#endif
#ifndef SOCKET_ERROR
#define SOCKET_ERROR            (-1)

typedef uint32_t SOCKET;
#endif
#endif

#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
#include <windows.h>
#include <WinSock.h>
#include <WinSock2.h>
#include <WS2tcpip.h>
#define closesocket closesocket
#elif (CC_TARGET_PLATFORM == CC_PLATFORM_IOS || CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <errno.h>
#include <sys/syscall.h>
#include <fcntl.h>
#include <netinet/tcp.h>
#define closesocket close
#endif


#ifndef SOCKET_SOTIMEOUT
#define SOCKET_SOTIMEOUT 30.0f
#endif

#ifndef SEND_BYTES 
#define SEND_BYTES  1024
#endif

#ifndef PACKAGE_HEAD_LEN
#define PACKAGE_HEAD_LEN 12
#endif

//连接超时时间间隔,3秒连接不上去，重连
#ifndef CONNECT_TIME_OUT_INTERVAL 
#define CONNECT_TIME_OUT_INTERVAL 3000
#endif

//重连最大次数
#ifndef RECONNECT_MAX_TIMES
#define RECONNECT_MAX_TIMES     5
#endif

//连接成功
#ifndef CMDID_CONNECTED
#define CMDID_CONNECTED         2
#endif

//断开链接
#ifndef CMDID_DISCONNECTED
#define CMDID_DISCONNECTED      3
#endif

//重连失败
#ifndef CMDID_RECONNECT_FAILED
#define CMDID_RECONNECT_FAILED  4
#endif

//heartbeat ping指令
#ifndef CMDID_HEART_BEAT_PING
#define CMDID_HEART_BEAT_PING   1006
#endif


#ifndef CMDID_ERROR
#define CMDID_ERROR 1000

#endif

#endif //__XNET_MACROS_H__
