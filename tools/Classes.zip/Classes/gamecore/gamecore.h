#include "cocos2d.h"

extern const char* xxtea_key = "92d8b4111dffcb9b33417fbb5ee53fa9";
extern int xxtea_key_len = 32;
