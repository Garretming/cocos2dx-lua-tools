
#pragma once

#include "cocos2d.h"

namespace gamecore {
    namespace ui {
        class MessageBox:public cocos2d::Ref{
			
        public:
			MessageBox(const char * msg, const char * title);

			static MessageBox* create(const char * msg, const char * title);
        };
    }
}


