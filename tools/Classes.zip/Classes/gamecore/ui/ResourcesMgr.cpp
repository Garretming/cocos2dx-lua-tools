
#include "ResourcesMgr.h"
#include <string>
#include <stdlib.h>
#include <vector>
#include <stdint.h>
#include <stdio.h>
#include <algorithm>
#include "spine/spine-cocos2dx.h"
#include "../crypto/Crypto.h"
#include "scripting/lua-bindings/manual/CCLuaEngine.h"
#include "scripting/lua-bindings/manual/LuaBasicConversions.h"

namespace gamecore {
	namespace ui {
		struct ResourcesMgr::AsyncImageStruct:public cocos2d::Ref
		{
		public:
			AsyncImageStruct(uint32_t handler, size_t count, size_t current, std::vector<std::string>& resources){
				_handler = handler;
				_count = count;
				_current = current;
				_resources = resources;
			}

			uint32_t _handler;
			size_t _count;
			size_t _current;
			std::vector<std::string> _resources;
		};


		

		ResourcesMgr* ResourcesMgr::m_Instance = nullptr;

		ResourcesMgr::ResourcesMgr()
		{

		}

		ResourcesMgr::~ResourcesMgr()
		{

		}

		ResourcesMgr* ResourcesMgr::getInstance()
		{
			if (m_Instance) {
				return m_Instance;
			}
			m_Instance = new (std::nothrow) ResourcesMgr();
			return m_Instance;
		}

		void ResourcesMgr::destroyInstance()
		{
			if (m_Instance) {
				delete m_Instance;
				m_Instance = nullptr;
			}
		}


		static char* memstr(char* data, size_t size, const char* substr)
		{
			if (data == nullptr || size <= 0 || substr == nullptr) {
				return nullptr;
			}

			if (*substr == '\0') {
				return nullptr;
			}

			size_t sublen = strlen(substr);

			int i;
			char* cur = data;
			size_t last_possible = size - sublen + 1;
			for (i = 0; i < last_possible; i++) {
				if (*cur == *substr) {
					if (memcmp(cur, substr, sublen) == 0) {
						return cur;
					}
				}
				cur++;
			}

			return nullptr;
		}


		std::string ResourcesMgr::getProtoData(std::string& filename, std::string& method, int& outLenght)
		{
			char _method[1024] = { 0 };

			for (ssize_t i = 0; i < method.length(); ++i) {
				_method[i * 2] = method[i] ^ 0xff;
				_method[i * 2 + 1] = method[i] ^ 0xff;
			}
			
			size_t base = method.size() * 2;

			cocos2d::Data data = cocos2d::FileUtils::getInstance()->getDataFromFile(filename);

			
			char* start = memstr((char*)data.getBytes(), data.getSize(), _method);

			cocos2d::Data ret_data;
			if (start) {
				int total = (unsigned char)(*(start + base)) << 24;
				total += (unsigned char)(*(start + base + 1)) << 16;
				total += (unsigned char)(*(start + base + 2)) << 8;
				total += (unsigned char)(*(start + base + 3));

				return gamecore::crypto::Crypto::decryptXXTEA((const char*)start + base + 4, total, outLenght);
				
			}
			return "";
		}

		cocos2d::Texture2D* ResourcesMgr::getTextrue(std::string& filename)
		{
			cocos2d::Texture2D* textrue = cocos2d::Director::getInstance()->getTextureCache()->getTextureForKey(filename);
			if (textrue == nullptr)
			{
				textrue = cocos2d::Director::getInstance()->getTextureCache()->addImage(filename);
			}
			return textrue;
		}

		cocos2d::Size ResourcesMgr::getFileNameSize(std::string& filename)
		{
			cocos2d::Texture2D* textrue = cocos2d::Director::getInstance()->getTextureCache()->getTextureForKey(filename);
			if (textrue == nullptr)
			{
				textrue = cocos2d::Director::getInstance()->getTextureCache()->addImage(filename);
			}
			
			if (textrue == nullptr)
			{
				return cocos2d::Size(0, 0);
			}

			return textrue->getContentSize();
		}


		void ResourcesMgr::addImageAsyncCallback(cocos2d::Texture2D* texture, AsyncImageStruct* imageStruct)
		{
			if (_vecAsyncImageStruct.find(imageStruct) == _vecAsyncImageStruct.end())
			{
				return;
			}
			imageStruct->_current = imageStruct->_current + 1;

			if (imageStruct->_current == imageStruct->_count && imageStruct->_handler > 0)
			{
				cocos2d::LuaStack* p = cocos2d::LuaEngine::getInstance()->getLuaStack();
				ccvector_std_string_to_luaval(p->getLuaState(), imageStruct->_resources);
				p->executeFunctionByHandler(imageStruct->_handler, 1);
				p->removeScriptHandler(imageStruct->_handler);

				_vecAsyncImageStruct.eraseObject(imageStruct);
			}
		}

		void ResourcesMgr::addImageAsync(uint32_t callback, std::vector<std::string>& resources)
		{
			if (resources.size() == 0)
			{
				this->addImageSync(callback, resources);
				return;
			}

			AsyncImageStruct* imageStruct = new AsyncImageStruct(callback, resources.size(), 0, resources);
			_vecAsyncImageStruct.pushBack(imageStruct);
			for (auto filename:resources)
			{
				cocos2d::Director::getInstance()->getTextureCache()->addImageAsync(filename, std::bind(&ResourcesMgr::addImageAsyncCallback, this, std::placeholders::_1, imageStruct));
			}
		}

		void ResourcesMgr::addImageAsyncProgress(uint32_t callback, std::vector<std::string>& resources)
		{
			if (resources.size() == 0 && callback) {
				cocos2d::LuaStack* p = cocos2d::LuaEngine::getInstance()->getLuaStack();
				p->pushLong(1);
				p->pushLong(1);
				p->pushString("");
				p->executeFunctionByHandler(callback, 3);
				p->removeScriptHandler(callback);
				return;
			}


			size_t count = resources.size();
			size_t current = 0;
			auto textureCallback = [&](cocos2d::Texture2D* texture)->void{
				current = current + 1;

				cocos2d::LuaStack* p = cocos2d::LuaEngine::getInstance()->getLuaStack();
				p->pushLong(current);
				p->pushLong(count);
				p->pushString(texture->getPath().c_str());
				p->executeFunctionByHandler(callback, 3);
				p->removeScriptHandler(callback);
			};

			for (auto filename : resources)
			{
				cocos2d::Director::getInstance()->getTextureCache()->addImageAsync(filename, textureCallback);
			}

		}

		void ResourcesMgr::addImageSync(uint32_t callback, std::vector<std::string>& resources)
		{
			for (auto filename:resources)
			{
				this->addImageSync(filename);
			}

			if (callback > 0)
			{
				cocos2d::LuaStack* p = cocos2d::LuaEngine::getInstance()->getLuaStack();
				ccvector_std_string_to_luaval(p->getLuaState(), resources);
				p->executeFunctionByHandler(callback, 1);
				p->removeScriptHandler(callback);
			}
			
		}

		void ResourcesMgr::addImageSync(std::string& resource)
		{
			cocos2d::Director::getInstance()->getTextureCache()->addImage(resource);
		}

		


		void ResourcesMgr::retainTextrue(std::string& filename)
		{
			std::string fullPath = FileUtils::getInstance()->fullPathForFilename(filename);
			if (_usingTextures.find(fullPath) != _usingTextures.end())
			{
				return;
			}
			auto texture = cocos2d::Director::getInstance()->getTextureCache()->addImage(fullPath);
			_usingTextures[fullPath] = texture;
			CC_SAFE_RETAIN(texture);

		}

		void ResourcesMgr::retainTextrues(std::vector<std::string>& resources)
		{
			for (auto filename : resources)
			{
				this->retainTextrue(filename);
			}
		}

		void ResourcesMgr::releaseTextrue(std::string& filename)
		{
			std::string fullPath = FileUtils::getInstance()->fullPathForFilename(filename);
			if (_usingTextures.find(fullPath) == _usingTextures.end())
			{
				return;
			}

			auto it = _usingTextures.find(fullPath);
			CC_SAFE_RELEASE(it->second);
			_usingTextures.erase(it);
		}

		void ResourcesMgr::releaseTextrues(std::vector<std::string>& resources)
		{
			for (auto filename : resources)
			{
				this->releaseTextrue(filename);
			}
		}


		void ResourcesMgr::addSpriteFramesWithFile(const std::string& plist)
		{
			CCASSERT(!plist.empty(), "plist filename should not be nullptr");

			std::string fullPath = FileUtils::getInstance()->fullPathForFilename(plist);

			if (fullPath.empty())
			{
				// return if plist file doesn't exist
				CCLOG("ResourcesMgr::addSpriteFramesWithFile: can not find %s", plist.c_str());
				return;
			}

			if (isSpriteFramesWithFileLoaded(fullPath))
			{
				return;
			}

			if (_plistDataMap.find(fullPath) == _plistDataMap.end())
			{
				std::string data = FileUtils::getInstance()->getStringFromFile(fullPath);

				std::string texturePath = plist;
				// remove .xxx
				size_t startPos = texturePath.find_last_of(".");
				texturePath = texturePath.erase(startPos);

				// append .png
				texturePath = texturePath.append(".png");

				_plistDataMap.insert(std::make_pair(fullPath, data));
				_plistImagePathMap.insert(std::make_pair(fullPath, texturePath));

			}

			_loadedSpriteFrameFileNames.insert(fullPath);

			SpriteFrameCache::getInstance()->addSpriteFramesWithFileContent(_plistDataMap.find(fullPath)->second, this->getTextrue(_plistImagePathMap.find(fullPath)->second));
			
		}

		void ResourcesMgr::addSpriteFramesWithFiles(std::vector<std::string>& plists)
		{
			for (auto filename : plists)
			{
				this->addSpriteFramesWithFile(filename);
			}
		}


		bool ResourcesMgr::isLoadedSpriteFrame(const std::string& frameName)
		{
			if (SpriteFrameCache::getInstance()->getSpriteFrameByName(frameName))
			{
				return true;
			}
			return false;
		}

		bool ResourcesMgr::isSpriteFramesWithFileLoaded(const std::string& plist)
		{
			bool result = false;

			if (_loadedSpriteFrameFileNames.find(plist) != _loadedSpriteFrameFileNames.end())
			{
				result = true;
			}

			return result;
		}

		void ResourcesMgr::retainSpriteFramesWithFile(std::string& filename)
		{
			std::string fullPath = FileUtils::getInstance()->fullPathForFilename(filename);
			if (!isSpriteFramesWithFileLoaded(fullPath))
			{
				return;
			}

			auto it = _usingSpriteFrames.find(fullPath);
			if (it != _usingSpriteFrames.end()) return;

			auto spriteFramesCache = SpriteFrameCache::getInstance();
			std::string data = _plistDataMap.find(fullPath)->second;

			ValueMap dict = FileUtils::getInstance()->getValueMapFromData(data.c_str(), static_cast<int>(data.size()));
			ValueMap& framesDict = dict["frames"].asValueMap();

			std::vector<SpriteFrame*> vec;
			for (auto iter = framesDict.begin(); iter != framesDict.end(); ++iter)
			{
				auto& spriteFrameName = iter->first;
				SpriteFrame* spriteFrame = spriteFramesCache->getSpriteFrameByName(spriteFrameName);
				vec.push_back(spriteFrame);
				CC_SAFE_RETAIN(spriteFrame);
			}
			_usingSpriteFrames[fullPath] = vec;

			this->retainTextrue(fullPath);
		}


		void ResourcesMgr::retainSpriteFramesWithFiles(std::vector<std::string>& resources)
		{
			for (auto filename : resources)
			{
				this->retainSpriteFramesWithFile(filename);
			}
		}

		void ResourcesMgr::releaseSpriteFramesWithFile(std::string& filename)
		{
			std::string fullPath = FileUtils::getInstance()->fullPathForFilename(filename);

			auto it = _usingSpriteFrames.find(fullPath);
			if (it == _usingSpriteFrames.end()) return;

			auto& vec = it->second;
			auto itFrame = vec.begin();
			while (itFrame != vec.end())
			{
				CC_SAFE_RELEASE(*itFrame);
				++itFrame;
			}
			vec.clear();
			_usingSpriteFrames.erase(it);

			this->releaseTextrue(fullPath);
		}

		void ResourcesMgr::releaseSpriteFramesWithFiles(std::vector<std::string>& resources)
		{
			for (auto filename : resources)
			{
				this->releaseSpriteFramesWithFile(filename);
			}
		}


		void ResourcesMgr::removeUnuseResouces()
		{
			SpriteFrameCache::getInstance()->removeUnusedSpriteFrames();
			cocos2d::Director::getInstance()->getTextureCache()->removeUnusedTextures();
			_loadedSpriteFrameFileNames.clear();
		}


		void ResourcesMgr::addSpineSkeletonDataAsyncProgress(uint32_t handler, std::vector<std::string>& resources)
		{
			if (resources.size() == 0 && handler)
			{
				cocos2d::LuaStack* p = cocos2d::LuaEngine::getInstance()->getLuaStack();
				p->pushLong(1);
				p->pushLong(1);
				p->executeFunctionByHandler(handler, 2);
				p->removeScriptHandler(handler);
				return;
			}

			
			cocos2d::Director::getInstance()->getScheduler()->schedule([&](float t)->void{

				auto filename = resources.front();
				resources.erase(resources.begin());

				std::string _atlasName = filename + ".atlas";
				std::string _jsonName = filename + ".json";


				spAtlas* atlas = spAtlas_createFromFile(_atlasName.c_str(), 0);
				spSkeletonJson* json = spSkeletonJson_create(atlas);
				spSkeletonData* data = spSkeletonJson_readSkeletonDataFile(json, _jsonName.c_str());
				//data->spAtlas = atlas;
				
				spSkeletonJson_dispose(json);

				if (m_SpineSkeletonDataMap.find(_atlasName) == m_SpineSkeletonDataMap.end())
				{
					// 
					m_SpineSkeletonDataMap.insert(std::make_pair(_atlasName, data));
				}

				if (resources.size() == 0)
				{
					cocos2d::Director::getInstance()->getScheduler()->unschedule("ResourcesMgr::addSkeletonDataAsyncProgress:timer", this);
				}
			}, this, 0.1, false, "ResourcesMgr::addSkeletonDataAsyncProgress:timer");
		}


		void* ResourcesMgr::getSpineSkeletonData(const std::string& filename)
		{
			return nullptr;
		}
		 
	}
}

