

#include "ConfigurationEx.h"

namespace gamecore {
    namespace ui {
        static cocos2d::Value _value;
        static std::string _string;
        
        std::string& ConfigurationEx::getStringValue(const std::string &key)
        {
            _value = cocos2d::Configuration::getInstance()->getValue(key);
            _string = _value.asString();
            return _string;
        }
        
		void ConfigurationEx::setStringValue(const std::string &key, const std::string& value)
        {
            cocos2d::Value _value(value);
            cocos2d::Configuration::getInstance()->setValue(key, _value);
        }
        
        
		bool ConfigurationEx::getBoolValue(const std::string &key)
        {
            _value = cocos2d::Configuration::getInstance()->getValue(key);
            return _value.asBool();
        }
        
		void ConfigurationEx::setBoolValue(const std::string &key, bool value)
        {
            cocos2d::Value _value(value);
            cocos2d::Configuration::getInstance()->setValue(key, _value);
        }
        
		int ConfigurationEx::getIntValue(const std::string &key)
        {
            _value = cocos2d::Configuration::getInstance()->getValue(key);
            return _value.asInt();
        }
        
		void ConfigurationEx::setIntValue(const std::string &key, int value)
        {
            cocos2d::Value _value(value);
            cocos2d::Configuration::getInstance()->setValue(key, _value);
        }
        
		double ConfigurationEx::getDoubleValue(const std::string &key)
        {
            _value = cocos2d::Configuration::getInstance()->getValue(key);
            return _value.asDouble();
        }
        
		void ConfigurationEx::setDoubleValue(const std::string &key, double value)
        {
            cocos2d::Value _value(value);
            cocos2d::Configuration::getInstance()->setValue(key, _value);
        }
    }
}
