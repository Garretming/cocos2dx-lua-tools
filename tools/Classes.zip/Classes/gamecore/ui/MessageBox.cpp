

#include "MessageBox.h"

namespace gamecore {
    namespace ui {

		MessageBox::MessageBox(const char * msg, const char * title)
		{
			cocos2d::MessageBox(msg, title);
		}
       
		MessageBox* MessageBox::create(const char * msg, const char * title)
		{
			auto instance = new MessageBox(msg, title);
			instance->autorelease();

			return instance;
		}
    }
}
