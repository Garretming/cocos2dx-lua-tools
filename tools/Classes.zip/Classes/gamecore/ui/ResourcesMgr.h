#pragma once
#include "cocos2d.h"


namespace gamecore {
	namespace ui {
		
		class ResourcesMgr:public cocos2d::Ref
		{
		protected:
			struct AsyncImageStruct;
			static ResourcesMgr* m_Instance;
			ResourcesMgr();
			virtual ~ResourcesMgr();

			std::unordered_map<std::string, std::string> _plistDataMap;
			std::unordered_map<std::string, std::string> _plistImagePathMap;
			std::unordered_map<std::string, void*> m_SpineSkeletonDataMap;
			std::map<std::string, std::vector<cocos2d::SpriteFrame*> > _usingSpriteFrames;
			std::map<std::string, cocos2d::Texture2D*> _usingTextures;
			cocos2d::Vector<AsyncImageStruct*> _vecAsyncImageStruct;
			std::set<std::string> _loadedSpriteFrameFileNames;
		protected:
			void addImageAsyncCallback(cocos2d::Texture2D* texture, AsyncImageStruct* imageStruct);
		public:
			static ResourcesMgr* getInstance();
			static void destroyInstance();

			//��ȡproto����
			std::string getProtoData(std::string& filename, std::string& method, int& size);

			cocos2d::Size getFileNameSize(std::string& filename);
			cocos2d::Texture2D* getTextrue(std::string& filename);
			//�첽����ͼƬ
			virtual void addImageAsync(uint32_t callback, std::vector<std::string>& resources);
			//ͬ������ͼƬ
			virtual void addImageSync(std::string& resource);

			//ͬ������ͼƬ
			virtual void addImageSync(uint32_t callback, std::vector<std::string>& resources);

			//�첽����ͼƬ��������
			virtual void addImageAsyncProgress(uint32_t callback, std::vector<std::string>& resources);

			//retainͼƬ
			virtual void retainTextrue(std::string& filename);
			virtual void retainTextrues(std::vector<std::string>& resources);

			//releaseͼƬ
			virtual void releaseTextrue(std::string& filename);
			virtual void releaseTextrues(std::vector<std::string>& resources);


			//����plist
			void addSpriteFramesWithFiles(std::vector<std::string>& plists);
			void addSpriteFramesWithFile(const std::string& plist);
			bool isSpriteFramesWithFileLoaded(const std::string& plist);
			bool isLoadedSpriteFrame(const std::string& frameName);

			//retain plist�ļ�
			virtual void retainSpriteFramesWithFile(std::string& filename);
			virtual void retainSpriteFramesWithFiles(std::vector<std::string>& resources);

			//release plist�ļ�
			virtual void releaseSpriteFramesWithFile(std::string& filename);
			virtual void releaseSpriteFramesWithFiles(std::vector<std::string>& resources);

			

			void removeUnuseResouces();

			//�첽���ع�������
			virtual void addSpineSkeletonDataAsyncProgress(uint32_t handler, std::vector<std::string>& resources);

			void* getSpineSkeletonData(const std::string& filename);
		};

		
		
	}
}

