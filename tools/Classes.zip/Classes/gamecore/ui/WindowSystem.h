
#pragma once

#include "cocos2d.h"

namespace gamecore {
    namespace ui {
        class WindowSystem{
			
        public:

			static void restart();
        };
    }
}


