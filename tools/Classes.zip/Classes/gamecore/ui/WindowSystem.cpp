

#include "WindowSystem.h"

namespace gamecore {
    namespace ui {

		void WindowSystem::restart()
		{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
			TCHAR moduleName[MAX_PATH];
			ZeroMemory(moduleName, sizeof(moduleName));
			GetModuleFileName(NULL, moduleName, MAX_PATH);

			STARTUPINFO si = { 0 };
			PROCESS_INFORMATION pi = { 0 };

			if (CreateProcess(NULL, moduleName, NULL, NULL, FALSE, NORMAL_PRIORITY_CLASS, NULL, NULL, &si, &pi))
			{
				ExitProcess(0);
			}
		}
#endif

    }
}
