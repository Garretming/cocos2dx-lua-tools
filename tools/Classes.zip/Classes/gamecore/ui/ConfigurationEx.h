
#pragma once

#include "cocos2d.h"

namespace gamecore {
    namespace ui {
        class ConfigurationEx{
        public:
            static std::string& getStringValue(const std::string& key);
            static void setStringValue(const std::string& key, const std::string& value);
            
            static bool getBoolValue(const std::string& key);
            static void setBoolValue(const std::string& key, bool value);

            
            static int getIntValue(const std::string& key);
            static void setIntValue(const std::string& key, int value);
            
            
            static double getDoubleValue(const std::string& key);
            static void setDoubleValue(const std::string& key, double value);
            
            
        };
    }
}


